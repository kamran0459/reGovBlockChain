package main

import (
	"encoding/json"
	"fmt"

	"github.com/hyperledger/fabric/core/chaincode/shim"
	pb "github.com/hyperledger/fabric/protos/peer"
)

func (t *UTCChainCode) stampRuleResult(stub hypConnect, args []string, functionName string) pb.Response {
	fmt.Println("stampRuleResult: ", args)
	if len(args) <= 0 {
		return shim.Error("Invalid Argument")
	}
	var status = getStatus()
	var processingStatus = getProcessingStatus()
	_utcRefNo := sanitize(args[0], "string").(string)
	_ruleID := sanitize(args[1], "string").(string)
	_UTCstatus := sanitize(args[2], "string").(string)
	_score := sanitize(args[3], "int").(int)
	_progress := sanitize(args[4], "int").(int)
	_financialRisk := sanitize(args[6], "int").(int)
	_duplicate := sanitize(args[7], "int").(int)
	generatedOn := sanitize(args[8], "int64").(int64)

	fmt.Println("\n\n  >>>>>>>>>. generatedOn >>  ", generatedOn)
	var _ruleResult []RuleResult
	unMerrR := json.Unmarshal([]byte(args[5]), &_ruleResult)
	if unMerrR != nil {
		fmt.Printf("%s\n", unMerrR)
		return shim.Error("Invalid Argument for Rules Result !!!!!!" + unMerrR.Error())
	}
	//ruleResultArray = _ruleResult

	bankCode, errorGetBankCode := getBankCode(stub, _utcRefNo)
	if errorGetBankCode != nil {
		fmt.Println("\n\n >>> ERROR OCCURRED getBankCode", errorGetBankCode.Error())
		return shim.Error(errorGetBankCode.Error())
	}
	if bankCode != "" {
		fmt.Println("\n\n >>>  getBankCode", bankCode)
	}

	//fetch existing document
	docCollection := "documents" + "_" + bankCode
	documentData, errorGetDocumentData := getDocumentData(stub, _utcRefNo, docCollection)
	if errorGetDocumentData != nil {
		fmt.Println("\n\n >>> ERROR OCCURRED " + errorGetDocumentData.Error())
		return shim.Error("\n\n >>> ERROR OCCURRED  : " + errorGetDocumentData.Error())
	}
	if (documentData.ProcessingStatus == processingStatus.Completed || documentData.ProcessingStatus == processingStatus.Corrected || documentData.ProcessingStatus == processingStatus.RuleProcessing) && documentData.Status == status.UnderProcess {
		fmt.Println("Document is going to process")
	} else {

		fmt.Println("\n\n ######### Document cannot be processed as the current status of the document is " + documentData.ProcessingStatus)
		return shim.Error("Document cannot be processed as the current status of the document is " + documentData.ProcessingStatus)
	}
	//if len(documentData.RuleResults) > 0 {
	//	var flagExist int
	//	flagExist = -1
	//	for index, elem := range documentData.RuleResults {
	//		if elem.RuleID == _ruleID {
	//			flagExist = index
	//		}
	//	}
	//	if flagExist != -1 {
	//		documentData.RuleResults[flagExist] = _ruleResult[flagExist]
	//	} else {
	//		documentData.RuleResults = append(documentData.RuleResults, _ruleResult...)
	//	}
	//
	//} else {
	//	documentData.RuleResults = nil
	//}
	if _progress > documentData.Progress {

		fmt.Printf("\n\n >>> _progress > documentData.Progress ")
		documentData.Score = _score
		documentData.UTCStatus = _UTCstatus
		documentData.Progress = _progress
		documentData.FinancialRisk = _financialRisk
		documentData.Duplicate = _duplicate
	}
	var processing bool
	processing = false
	if _progress == 100 {

		fmt.Printf("\n\n >>>_progress == 100 ")
		documentData.ProcessingStatus = processingStatus.ProcessCompleted
		batchBytesDataToInsert, errorFromFunction := GetBatchDetailByIDOrUpdateStatus(stub, documentData.BatchNo, bankCode, 1, documentData.UTCRefNo, processingStatus.ProcessCompleted)
		if errorFromFunction != nil {
			fmt.Println("Marshal failed for documentData !!!!!!", errorFromFunction)
			return shim.Error(errorFromFunction.Error())
		}
		docBatchCollection := "documentBatch" + "_" + bankCode
		errorInsertBatchData := insertData(&stub, documentData.BatchNo, docBatchCollection, batchBytesDataToInsert)
		//raise shim error message if insertion fails.
		if errorInsertBatchData != nil {
			fmt.Println("Insertion failed of documentBatchDataMarshalled !!!!!!", errorInsertBatchData)
			return shim.Error(errorInsertBatchData.Error())
		}
	} else {
		documentData.ProcessingStatus = processingStatus.RuleProcessing
		batchBytesDataToInsert, errorFromFunction := GetBatchDetailByIDOrUpdateStatus(stub, documentData.BatchNo, bankCode, 1, documentData.UTCRefNo, processingStatus.RuleProcessing)
		if errorFromFunction != nil {
			fmt.Println("Marshal failed for documentData !!!!!!", errorFromFunction)
			return shim.Error(errorFromFunction.Error())
		}
		docBatchCollection := "documentBatch" + "_" + bankCode
		errorInsertBatchData := insertData(&stub, documentData.BatchNo, docBatchCollection, batchBytesDataToInsert)
		//raise shim error message if insertion fails.
		if errorInsertBatchData != nil {
			fmt.Println("Insertion failed of documentBatchDataMarshalled !!!!!!", errorInsertBatchData)
			return shim.Error(errorInsertBatchData.Error())
		}
		processing = true
	}

	fmt.Println("\n\n >>> before  raiseNotification  !!!!!!")
	//policyType := getPolicyType()
	// Add the each Ruleresult in the array to a different privat collection
	var ruleResultIDs []string
	for i := range _ruleResult {
		//var complaincePlicyResult string
		//complaincePlicyResult = getComplaincePolicy()

		_ruleResult[i].Key = documentData.UTCRefNo + "_" + _ruleResult[i].RuleID
		_ruleResult[i].DocumentName = "documentruleresult"

		getRuleType := getRuleType()
		teamType := getTeamType()
		complaincePolicyType := getPolicyType()
		fmt.Println("\n\n >>>>>>>  _ruleResult[i].RuleType  !!!!!!", _ruleResult[i].RuleType)
		fmt.Println(">>>>>>  _ruleResult[i].RuleCategory  !!!!!!", _ruleResult[i].RuleCategory)
		if _ruleResult[i].RuleType == getRuleType.FIELDMATCH && _ruleResult[i].RuleCategory == getRuleType.DUPLICATE {

			duplicate := _ruleResult[i].Duplicate
			utcRefNew := _utcRefNo
			fmt.Println("\n >>> Inside   raiseNotification >>>>>>>>>. ")
			for j := 0; j < len(duplicate); j++ {

				fmt.Println("\n\n >>> INSIDE  LOOP DuPLICATe >>>>>>>>>. ")
				var utcRefDocument UTCRefBankMapping
				utcRefReal := duplicate[j].UTCRefNo
				UTCrefDocBytes, err := fetchData(stub, "MAP_"+utcRefReal, "utcRefBankMapping")
				if err != nil {
					fmt.Println("Error occurred while fetching document from utcRefBankMapping with key : " + utcRefReal)
					return shim.Error("Error occurred while fetching document from utcRefBankMapping with key  : " + utcRefReal + " " + err.Error())
				}
				if UTCrefDocBytes == nil {
					return shim.Error("Document not found with Key: ")
				}

				errorUnmarshal := json.Unmarshal(UTCrefDocBytes, &utcRefDocument)
				if errorUnmarshal != nil {
					fmt.Println("Errro occurred while unmarshallling utcRefDocument ", errorUnmarshal)
				}

				// inserting correlation in invoice real
				invoiceCorrlnnReal := InvoiceCorrelation{}
				invoiceCorrelationBytes, err := fetchData(stub, utcRefReal, "invoiceCorrelation")
				if err != nil {
					fmt.Println("Error occurred while fetching document from utcRefBankMapping with key : " + utcRefReal)
					return shim.Error("Error occurred while fetching document from utcRefBankMapping with key  : " + utcRefReal + " " + err.Error())
				}
				errUnmarshal := json.Unmarshal(invoiceCorrelationBytes, &invoiceCorrlnnReal)
				if errUnmarshal != nil {
					fmt.Println("Errro occurred while unmarshallling invoiceCorrelation ", errUnmarshal)
				}

				invoiceCorrlnnReal.Key = utcRefReal
				invoiceCorrlnnReal.MyImpact = append(invoiceCorrlnnReal.MyImpact, utcRefNew)

				marshalledCorrelation, errorMarshal := json.Marshal(invoiceCorrlnnReal)
				if errorMarshal != nil {
					fmt.Println("Errro occurred while marshallling invoiceCorrlnnReal ", errorMarshal)
				}

				errorinvoiceCorrelation := insertData(&stub, invoiceCorrlnnReal.Key, "invoiceCorrelation", marshalledCorrelation)
				if errorinvoiceCorrelation != nil {
					fmt.Println("Insertion failed of invoiceCorrelationMarshalled !!!!!!", errorinvoiceCorrelation)
					return shim.Error(errorinvoiceCorrelation.Error())
				}
				fmt.Println("\n\n >>> inserted data in  invoiceCorrelation real >>>>>>>>>. ")
				//inserting correlation of invoice duplicate
				invceCorrlnduplicate := InvoiceCorrelation{}

				invoiceCorrlationBytes, err := fetchData(stub, utcRefNew, "invoiceCorrelation")
				if err != nil {
					fmt.Println("Error occurred while fetching document from utcRefBankMapping with key : " + utcRefNew)
					return shim.Error("Error occurred while fetching document from utcRefBankMapping with key  : " + utcRefNew + " " + err.Error())
				}
				errUnmarshl := json.Unmarshal(invoiceCorrlationBytes, &invceCorrlnduplicate)
				if errUnmarshl != nil {
					fmt.Println("Errro occurred while unmarshallling invoiceCorrelation ", errUnmarshl)
				}
				invceCorrlnduplicate.Key = utcRefNew
				invceCorrlnduplicate.ImpactedBy = append(invceCorrlnduplicate.ImpactedBy, utcRefReal)

				marshallCorrelation, errorMarshal := json.Marshal(invceCorrlnduplicate)
				if errorUnmarshal != nil {
					fmt.Println("Errro occurred while marshallling invoiceCorrln ", errorMarshal)
				}
				errorinvoiceCorrelation = insertData(&stub, invceCorrlnduplicate.Key, "invoiceCorrelation", marshallCorrelation)
				//raise shim error message if insertion fails.
				if errorinvoiceCorrelation != nil {
					fmt.Println("Insertion failed of invoiceCorrelationMarshalled !!!!!!", errorinvoiceCorrelation)
					return shim.Error(errorinvoiceCorrelation.Error())
				}
				fmt.Println("\n\n >>> inserted data in  invoiceCorrelation real >>>>>>>>>. ")

				message := "Duplicate invoice has been detected in the UTC system."
				if duplicate[j].DocumentNo != "" {
					message = "Duplicate invoice " + duplicate[j].DocumentNo + " has been detected in the UTC system."
				}

				fmt.Println("\n ~~~~ Notification message ::: ", message)

				notificatn := &NotificationOnSameInvoice{
					DocumentName: "Notification",
					Key:          duplicate[j].UUID,
					MessageText:  message,
					CreatedOn:    generatedOn,
					Type:         teamType.OPERATIONAL,
				}

				if bankCode != utcRefDocument.BankCode {

					fmt.Println("\n\n  ~~~~~~~~ Duplicates received from different banks !! ", bankCode, " ", utcRefDocument.BankCode)

					// getcomplaince policy and check whether policy type is complete | none | matching
					complainceSttngs := ComplainceSetting{}
					complainceKey := "COMPLAINCE-POLICY"
					complainceSettingBytes, err := fetchData(stub, complainceKey, "complainceSetting")
					if err != nil {
						fmt.Println("Error occurred while fetching complainceSetting with key : " + complainceKey)
						return shim.Error("Error occurred while fetchingcomplainceSetting with key  : " + complainceKey + " " + err.Error())
					}
					errUnmarshl := json.Unmarshal(complainceSettingBytes, &complainceSttngs)
					if errUnmarshl != nil {
						fmt.Println("Errro occurred while unmarshallling ComplainceSetting ", errUnmarshl)
					}

					fmt.Println("\n >>>  Complaince policy fetched :: ", complainceSttngs)

					// one check is missing >> for MATCHING fields
					if complainceSttngs.PolicyType == complaincePolicyType.COMPLETE {
						notificatn.InputFields = duplicate
					} else if complainceSttngs.PolicyType == complaincePolicyType.NONE {
						notificatn.InputFields = append(notificatn.InputFields, duplicateDetail{
							ProcessDate: duplicate[j].ProcessDate,
							Status:      duplicate[j].Status})
					} else {
						notificatn.InputFields = append(notificatn.InputFields, duplicateDetail{
							DocumentNo: "",
							UTCRefNo:   "",
						})
					}
				}

				notificatnMarshalled, errorMarshal := json.Marshal(notificatn)
				if errorMarshal != nil {
					fmt.Println("Marshal failed for notificatn Document !!!!!!", errorMarshal)
					return shim.Error(errorMarshal.Error())
				}
				fmt.Println("Marshalled notificatnArray: ", notificatnMarshalled)
				fmt.Println("\n\n >>> inserted data in  notification real >>>>>>>>>. ")
				errorInsert := insertData(&stub, notificatn.Key, "notification_"+utcRefDocument.BankCode, notificatnMarshalled)
				//raise shim error message if insertion fails.
				if errorInsert != nil {
					fmt.Println("Insertion failed of notificatn !!!!!!", errorInsert)
					return shim.Error(errorInsert.Error())
				}

			}

			// }
		}

		ruleResultMarshalled, errorMarshal := json.Marshal(_ruleResult[i])
		if errorMarshal != nil {
			fmt.Println("Marshal failed for ruleResult Document !!!!!!", errorMarshal)
			return shim.Error(errorMarshal.Error())
		}
		fmt.Println("Marshalled ruleResultArray: ", ruleResultMarshalled)
		ruleResultKey := _ruleResult[i].Key

		//documentRulesResult  with bankCode
		errorInsert := insertData(&stub, ruleResultKey, "documentRulesResult", ruleResultMarshalled)
		//raise shim error message if insertion fails.
		if errorInsert != nil {
			fmt.Println("Insertion failed of documentDataMarshalled !!!!!!", errorInsert)
			return shim.Error(errorInsert.Error())
		}
		ruleResultIDs = append(ruleResultIDs, ruleResultKey)
	}

	documentData.RuleResultIDs = append(documentData.RuleResultIDs, ruleResultIDs...)
	documentData.RuleProcessingDate = generatedOn
	documentData.BankCode = bankCode

	fmt.Println("=========>>>>>>>>>>> RuleIDs : ", documentData.RuleResultIDs)
	fmt.Println("\n\n >>>>>>>>> RuleProcessingDate >>>>>>>> ", documentData.RuleProcessingDate)

	fmt.Println("\n\n >>>>>>>>> bankCode >>>>>>>> ", documentData.BankCode)

	documentDataMarshalled, errorMarshal := json.Marshal(documentData)
	if errorMarshal != nil {
		fmt.Println("Marshal failed for documentData !!!!!!", errorMarshal)
		return shim.Error(errorMarshal.Error())
	}
	fmt.Println("Marshalled documentData: ", documentDataMarshalled)
	errorInsert := insertData(&stub, documentData.Key, docCollection, documentDataMarshalled)
	//raise shim error message if insertion fails.
	if errorInsert != nil {
		fmt.Println("Insertion failed of documentDataMarshalled !!!!!!", errorInsert)
		return shim.Error(errorInsert.Error())
	}

	if !processing {
		fmt.Println("\n\n >>>>>>>> STUB EVENTLIST >>>>>>>>>>>>>>    ", stub.EventList)
		_, _ = RaiseEventData(stub, "EventOnRuleProcessComplete", _ruleID)
	} else {
		_, _ = RaiseEventData(stub, "EventOnDocumentProcessing", _ruleID)
	}
	return shim.Success(nil)
}
