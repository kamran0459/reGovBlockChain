package main

import (
	"fmt"
	"reflect"
)

func computeMismatchAndProcessing(ocrData map[string]interface{}, electronicData map[string]interface{}, attributes []Attribute, override bool) ([]MismatchField, map[string]interface{}) {
	var tempMismatch []MismatchField
	tempProcessing := make(map[string]interface{})

	for _, val := range attributes {
		if reflect.TypeOf(ocrData[val.Mapping]) == reflect.TypeOf(electronicData[val.Mapping]) {
			fmt.Println("type match")
			if _, ok := (ocrData[val.Mapping]).([]interface{}); ok {
				fmt.Println("slice", val.Mapping)
				ocrSlice := ocrData[val.Mapping].([]interface{})
				electronicSlice := electronicData[val.Mapping].([]interface{})
				fmt.Println("ocrSlice data: ", ocrSlice)
				fmt.Println("electronicSlice data: ", electronicSlice)
				max := getMax(len(ocrSlice), len(electronicSlice))
				tempSlice := make([]interface{}, max)
				for j := 0; j < max; j++ {
					fmt.Println("ocrSlice data index: ", j, ocrSlice[j])
					fmt.Println("electronicSlice data index: ", j, electronicSlice[j])
					if ok := reflect.DeepEqual(ocrSlice[j], electronicSlice[j]); ok {
						fmt.Println("value match")
						tempSlice[j] = ocrSlice[j]
					} else {
						fmt.Println("value mismatch")
						fmt.Println("override value: ", override)
						if override {
							tempSlice[j] = electronicSlice[j]
						} else {
							tempSlice[j] = nil
						}
						temp := &MismatchField{
							FieldName: val.Mapping,
							Index:     j,
						}
						tempMismatch = append(tempMismatch, *temp)
					}

				}
				tempProcessing[val.Mapping] = tempSlice
			} else {
				fmt.Println("not a slice", val.Mapping)
				if ok := reflect.DeepEqual(ocrData[val.Mapping], electronicData[val.Mapping]); ok {
					fmt.Println("value match")
					tempProcessing[val.Mapping] = ocrData[val.Mapping]
				} else {
					fmt.Println("value mismatch")
					fmt.Println("override value: ", override)
					if override {
						tempProcessing[val.Mapping] = electronicData[val.Mapping]
					} else {
						tempProcessing[val.Mapping] = nil
					}
					temp := &MismatchField{
						FieldName: val.Mapping,
						Index:     -1,
					}
					tempMismatch = append(tempMismatch, *temp)
				}
			}
		} else {
			fmt.Println("type mismatch in case of array", reflect.TypeOf(ocrData[val.Mapping]), val.Mapping)
			rt := reflect.TypeOf(ocrData[val.Mapping])
			if rt.Kind() == reflect.Slice || rt.Kind() == reflect.Array {
				fmt.Println("\ntype is array\n")
				for i, _ := range ocrData[val.Mapping].([]interface{}) {
					temp := &MismatchField{
						FieldName: val.Mapping,
						Index:     i,
					}
					tempMismatch = append(tempMismatch, *temp)
				}
			} else {
				tempProcessing[val.Mapping] = nil
				temp := &MismatchField{
					FieldName: val.Mapping,
					Index:     -1,
				}
				tempMismatch = append(tempMismatch, *temp)
			}
		}
	}

	return tempMismatch, tempProcessing
}
