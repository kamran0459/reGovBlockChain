package main

type MSPList struct {
	OrgType string `json:"orgType"`
	MSP     string `json:"MSP"`
	ID      string `json:"ID"`
}

type RuleSet struct {
	Key             string        `json:"key"`
	DocumentName    string        `json:"documentName"`
	Country         string        `json:"country"`
	Industry        string        `json:"industry"`
	DocumentType    string        `json:"documentType"`
	DocumentSubType string        `json:"subType"`
	PassRange       string        `json:"passRange"`
	FailRange       string        `json:"failRange"`
	ManualRange     []ManualRange `json:"manualRange"`
	Rules           []Rules       `json:"rules"`
}
type ManualRange struct {
	Operator string `json:"operator"`
	Value    int    `json:"value"`
}

type Rules struct {
	Name             string          `json:"name"`
	Description      string          `json:"description"`
	Score            string          `json:"score"`
	OutputType       string          `json:"outputType"`
	Algorithm        string          `json:"algorithm"`
	Action           string          `json:"action"`
	FieldInputs      FieldsInputs    `json:"fieldInputs"`
	AlgorithmInputs  AlgorithmInputs `json:"algorithmInputs"`
	RuleType         string          `json:"ruleType"`
	RuleCategory     string          `json:"ruleCategory"`
	Index            int             `json:"index"`
	AdditionalFields []string        `json:"additionalFields"`
	Clusters         []Clusters      `json:"clusters"`
}

type Clusters struct {
	Score int            `json:"score"`
	Rules []ClusterRules `json:"rules"`
}
type ClusterRules struct {
	Value    int    `json:"value"`
	Operator string `json:"operator"`
	RuleID   string `json:"ruleID"`
}

type FieldsInputs struct {
	MinOptionalMatches string            `json:"minOptionalMatches"`
	OptionalFields     []OptionalFields  `json:"optionalFields"`
	MandatoryFields    []MandatoryFields `json:"mandatoryFields"`
}

type OptionalFields struct {
	Key       string `json:"key"`
	Type      string `json:"type"`
	Function  string `json:"function"`
	Operation string `json:"operation"`
	Distance  string `json:"distance"`
}

type MandatoryFields struct {
	Key       string `json:"key"`
	Type      string `json:"type"`
	Function  string `json:"function"`
	Operation string `json:"operation"`
	Distance  string `json:"distance"`
}

type AlgorithmInputs struct {
	Context   []string  `json:"context"`
	Outputs   []Outputs `json:"outputs"`
	Algorithm string    `json:"algorithm"`
}
type ComplainceSetting struct {
	DocumentNo  string                   `json:"documentNo"` // should go in any case
	Key         string                   `json:"key"`
	PolicyType  string                   `json:"policyType"`
	Fields      []map[string]interface{} `json:"fields"`
	ProcessDate string                   `json:"processDate"` // should go in any case
	Status      string                   `json:"status"`      // should go in any case
}
type Outputs struct {
	Field string `json:"field"`
	Index string `json:"index"`
}

type UTCRef struct {
	DocumentNo     string `json:"documentNo"`
	UTCRefNo       string `json:"UTCRefNo"`
	BatchIndex     int    `json:"batchIndex"`
	DocumentStatus string `json:"documentStatus"`
}

type Customer struct {
	Name            string            `json:"name"`
	TaxNo           string            `json:"taxNo"`
	BuyerOrSupplier string            `json:"buyerOrSupplier"`
	TradeLicenseNo  string            `json:"tradeLicenseNo"`
	AdditionalData  map[string]string `json:"additionalData"` // Dynamic struct
}

type RuleResult struct {
	DocumentName    string                   `json:"documentName"`
	Key             string                   `json:"key"`
	RuleID          string                   `json:"ruleID"`
	Step            string                   `json:"step"`
	RuleType        string                   `json:"ruleType"`
	RuleCategory    string                   `json:"ruleCategory"`
	Status          string                   `json:"status"`
	OutputType      string                   `json:"outputType"`
	AvailableScore  int                      `json:"availableScore"`
	IsImmediateFail bool                     `json:"isImmediateFail"`
	RuleFailed      bool                     `json:"ruleFailed"`
	Input           []map[string]interface{} `json:"input"`
	Fields          []string                 `json:"fields"`
	Output          []map[string]interface{} `json:"output"`
	Duplicate       []duplicateDetail        `json:"duplicates"`
}
type duplicateDetail struct {
	UTCRefNo        string `json:"utcRefNo"`
	BuyerOrSupplier string `json:"buyerOrSupplier"`
	DocumentNo      string `json:"documentNo"`
	FileHash        string `json:"fileHash"`
	ProcessDate     string `json:"processDate"`
	Status          string `json:"status"`
	UUID            string `json:"UUID"`
}
type DocumentBatch struct {
	DocumentName   string           `json:"documentName"`
	Key            string           `json:"key"`
	BatchNo        string           `json:"batchNo"`
	BatchIndex     int              `json:"batchIndex"`
	UTCRefList     []UTCRef         `json:"UTCRefList"`
	BatchFileImage []BatchFileImage `json:"batchFileImage"`
	Customer       Customer         `json:"customer"`
	DocumentCount  int              `json:"documentCount"`
	UploadedOn     int64            `json:"uploadedOn"`
	UploadedBy     string           `json:"uploadedBy"`
	UploadType     string           `json:"uploadType"`
	BankRefNumbers []string         `json:"bankRefNumbers"`
	Type           string           `json:"type"`
	BankCode       string           `json:"bankCode"`
}

type BatchFileImage struct {
	Name string `json:"name"`
	Type string `json:"type"`
	Hash string `json:"hash"`
	Path string `json:"path"`
}

type UTCRefBankMapping struct {
	Key          string `json:"key"`
	DocumentName string `json:"documentName"`
	BankCode     string `json:"bankCode"`
	DocumentNo   string `json:"documentNo"`
	BatchNo      string `json:"batchNo"`
}

type Document struct {
	Key                string                 `json:"key"`
	DocumentName       string                 `json:"documentName"`
	DocumentNo         string                 `json:"documentNo"`
	UTCRefNo           string                 `json:"UTCRefNo"`
	BatchNo            string                 `json:"batchNo"`
	DocumentType       string                 `json:"documentType"`
	DocumentSubType    string                 `json:"documentSubType"`
	Customer           Customer               `json:"customer"`
	Override           bool                   `json:"override"`
	RuleSetID          string                 `json:"ruleSetID"`
	Score              int                    `json:"score"`
	RuleResults        []RuleResult           `json:"ruleResults"`
	OCRData            map[string]interface{} `json:"OCRData"`        // Dynamic struct
	ProcessingData     map[string]interface{} `json:"processingData"` // Dynamic struct
	ElectronicData     map[string]interface{} `json:"electronicData"` // Dynamic struct
	Status             string                 `json:"status"`
	ProcessingStatus   string                 `json:"processingStatus"`
	MismatchFields     []MismatchField        `json:"mismatchFields"`
	CorrectData        CorrectData            `json:"correctData"`
	UploadedOn         int64                  `json:"uploadedOn"`
	UploadedBy         string                 `json:"uploadedBy"`
	UTCStatus          string                 `json:"UTCStatus"`
	Progress           int                    `json:"progress"`
	FinancialRisk      int                    `json:"financialRisk"`
	Duplicate          int                    `json:"duplicate"`
	UploadType         string                 `json:"uploadType"`
	BankRefNumbers     []string               `json:"bankRefNumbers"`
	Type               string                 `json:"type"`
	RuleResultIDs      []string               `json:"ruleResultIDs"`
	FileHash           string                 `json:"fileHash"`
	CompanyStamp       string                 `json:"companyStamp"`
	CompanySignatory   string                 `json:"companySignatory"`
	CompanyLogo        string                 `json:"companyLogo"`
	BankCode           string                 `json:"bankCode"`
	RuleProcessingDate int64                  `json:"ruleProcessingDate"`
	ProcessedBy        string                 `json:"processedBy"`
	ProcessDate        int64                  `json:"processDate"`
}

type CorrectData struct {
	DocumentNo string      `json:"documentNo"`
	UTCRefNo   string      `json:"UTCRefNo"`
	FieldsData []FieldData `json:"fieldsData"`
}

type FieldData struct {
	FieldName string      `json:"fieldName"`
	Index     int         `json:"index"`
	Value     interface{} `json:"value"`
}

type MetaInfo struct {
	Key           string      `json:"key"`
	DocumentName  string      `json:"documentName"`
	Name          string      `json:"name"`
	Description   string      `json:"description"`
	Type          string      `json:"type"`
	SubType       string      `json:"subType"`
	AttributeList []Attribute `json:"fields"`
}

type Attribute struct {
	Occur   string `json:"occur"`
	Mapping string `json:"mapping"`
	Name    string `json:"name"`
}

type MismatchField struct {
	FieldName string `json:"fieldName"`
	Index     int    `json:"index"`
}

type AdditionalBatchData struct {
	BatchIndex int `json:"batchIndex"`
}

type NotificationOnSameInvoice struct {
	DocumentName string            `json:"documentName"`
	Key          string            `json:"key"`
	InputFields  []duplicateDetail `json:"inputFields"`
	CreatedOn    int64             `json:"createdOn"`
	Type         string            `json:"type"` //OPS | GOV
	MessageText  string            `json:"messageText"`
}

type InvoiceCorrelation struct {
	Key        string   `json:"key"`
	MyImpact   []string `json:"myImpact"`
	ImpactedBy []string `json:"impactedBy"`
}

// type inputFields struct {
// 	Key   string `json:"key"`
// 	Value string `json:"value"`
// }
