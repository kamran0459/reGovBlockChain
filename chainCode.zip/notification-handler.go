package main

import (
	"encoding/json"
	"fmt"

	"github.com/hyperledger/fabric/core/chaincode/shim"
	pb "github.com/hyperledger/fabric/protos/peer"
)

// func (t *UTCChainCode) raiseNotification(utcRefNew string, stub *hypConnect, duplicate []duplicateDetail, bankCode string, generatedOn int64) error {
// 	fmt.Println("\n\n >>> INSIDE  raiseNotification >>>>>>>>>. ")
// 	for j := 0; j < len(duplicate); j++ {

// 		fmt.Println("\n\n >>> INSIDE  LOOP DuPLICATe >>>>>>>>>. ")
// 		var utcRefDocument UTCRefBankMapping
// 		utcRefReal := duplicate[j].UTCRefNo
// 		UTCrefDocBytes, err := fetchData(*stub, "MAP_"+utcRefReal, "utcRefBankMapping")
// 		if err != nil {
// 			fmt.Println("Error occurred while fetching document from utcRefBankMapping with key : " + utcRefReal)
// 			return errors.New("Error occurred while fetching document from utcRefBankMapping with key  : " + utcRefReal + " " + err.Error())
// 		}
// 		if UTCrefDocBytes == nil {
// 			return errors.New("Document not found with Key: ")
// 		}

// 		errorUnmarshal := json.Unmarshal(UTCrefDocBytes, &utcRefDocument)
// 		if errorUnmarshal != nil {
// 			fmt.Println("Errro occurred while unmarshallling utcRefDocument ", errorUnmarshal)
// 		}

// 		// inserting correlation in invoice real
// 		invoiceCorrlnnReal := InvoiceCorrelation{}
// 		invoiceCorrelationBytes, err := fetchData(*stub, utcRefReal, "invoiceCorrelation")
// 		if err != nil {
// 			fmt.Println("Error occurred while fetching document from utcRefBankMapping with key : " + utcRefReal)
// 			return errors.New("Error occurred while fetching document from utcRefBankMapping with key  : " + utcRefReal + " " + err.Error())
// 		}
// 		errUnmarshal := json.Unmarshal(invoiceCorrelationBytes, &invoiceCorrlnnReal)
// 		if errUnmarshal != nil {
// 			fmt.Println("Errro occurred while unmarshallling invoiceCorrelation ", errUnmarshal)
// 		}

// 		invoiceCorrlnnReal.Key = utcRefReal
// 		invoiceCorrlnnReal.MyImpact = append(invoiceCorrlnnReal.MyImpact, utcRefNew)

// 		marshalledCorrelation, errorMarshal := json.Marshal(invoiceCorrlnnReal)
// 		if errorMarshal != nil {
// 			fmt.Println("Errro occurred while marshallling invoiceCorrlnnReal ", errorMarshal)
// 		}

// 		errorinvoiceCorrelation := insertData(stub, invoiceCorrlnnReal.Key, "invoiceCorrelation", marshalledCorrelation)
// 		if errorinvoiceCorrelation != nil {
// 			fmt.Println("Insertion failed of invoiceCorrelationMarshalled !!!!!!", errorinvoiceCorrelation)
// 			return errors.New(errorinvoiceCorrelation.Error())
// 		}
// 		fmt.Println("\n\n >>> inserted data in  invoiceCorrelation real >>>>>>>>>. ")
// 		//inserting correlation of invoice duplicate
// 		invceCorrlnduplicate := InvoiceCorrelation{}

// 		invoiceCorrlationBytes, err := fetchData(*stub, utcRefNew, "invoiceCorrelation")
// 		if err != nil {
// 			fmt.Println("Error occurred while fetching document from utcRefBankMapping with key : " + utcRefNew)
// 			return errors.New("Error occurred while fetching document from utcRefBankMapping with key  : " + utcRefNew + " " + err.Error())
// 		}
// 		errUnmarshl := json.Unmarshal(invoiceCorrlationBytes, &invceCorrlnduplicate)
// 		if errUnmarshl != nil {
// 			fmt.Println("Errro occurred while unmarshallling invoiceCorrelation ", errUnmarshl)
// 		}
// 		invceCorrlnduplicate.Key = utcRefNew
// 		invceCorrlnduplicate.ImpactedBy = append(invceCorrlnduplicate.ImpactedBy, utcRefReal)

// 		marshallCorrelation, errorMarshal := json.Marshal(invceCorrlnduplicate)
// 		if errorUnmarshal != nil {
// 			fmt.Println("Errro occurred while marshallling invoiceCorrln ", errorMarshal)
// 		}
// 		errorinvoiceCorrelation = insertData(stub, invceCorrlnduplicate.Key, "invoiceCorrelation", marshallCorrelation)
// 		//raise shim error message if insertion fails.
// 		if errorinvoiceCorrelation != nil {
// 			fmt.Println("Insertion failed of invoiceCorrelationMarshalled !!!!!!", errorinvoiceCorrelation)
// 			return errors.New(errorinvoiceCorrelation.Error())
// 		}
// 		fmt.Println("\n\n >>> inserted data in  invoiceCorrelation real >>>>>>>>>. ")
// 		if bankCode != utcRefDocument.BankCode {
// 			duplicate[j].DocumentNo = ""
// 			duplicate[j].UTCRefNo = ""
// 		}

// 		// complaince policy -------
// 		fmt.Println("\n\n >>> duplicate >>>>>>>>>. ", duplicate)
// 		notificatn := &NotificationOnSameInvoice{
// 			DocumentName: "Notification",
// 			Key:          duplicate[j].UUID,
// 			MessageText:  "This invoice already exist in the system",
// 			InputFields:  duplicate, //complaince fields
// 			CreatedOn:    generatedOn,
// 			Type:         getTeamType().OPERATIONAL,
// 		}

// 		notificatnMarshalled, errorMarshal := json.Marshal(notificatn)
// 		if errorMarshal != nil {
// 			fmt.Println("Marshal failed for notificatn Document !!!!!!", errorMarshal)
// 			return errors.New(errorMarshal.Error())
// 		}
// 		fmt.Println("Marshalled notificatnArray: ", notificatnMarshalled)
// 		fmt.Println("\n\n >>> inserted data in  notification real >>>>>>>>>. ")
// 		errorInsert := insertData(stub, notificatn.Key, "notification_"+utcRefDocument.BankCode, notificatnMarshalled)
// 		//raise shim error message if insertion fails.
// 		if errorInsert != nil {
// 			fmt.Println("Insertion failed of notificatn !!!!!!", errorInsert)
// 			return errors.New(errorInsert.Error())
// 		}

// 	}
// 	return nil
// }

// stub hypConnect, args []string, functionName string) pb.Response
func (t *UTCChainCode) raiseNotificationOnPurge(stub hypConnect, args []string, functionName string) pb.Response {

	fmt.Println("\n\n >>>>>>>> ARGUMENTS RECEIVED ::: ", args)

	generatedOn := sanitize(args[1], "int64").(int64)
	UUID := sanitize(args[2], "string").(string)
	UTCRefNo := sanitize(args[0], "string").(string)
	Status := sanitize(args[3], "string").(string)
	invoiceNo := sanitize(args[4], "string").(string)

	// for _, document := range document {
	invoiceCorrlnnReal := InvoiceCorrelation{}

	invoiceCorrelationBytes, err := fetchData(stub, UTCRefNo, "invoiceCorrelation")
	if err != nil {
		fmt.Println("Error occurred while fetching document from invoiceCorrelation with key : " + UTCRefNo)
		return shim.Error("Error occurred while fetching document from invoiceCorrelation with key  : " + UTCRefNo + " " + err.Error())
	}
	errUnmarshal := json.Unmarshal(invoiceCorrelationBytes, &invoiceCorrlnnReal)
	if errUnmarshal != nil {
		fmt.Println("Errro occurred while unmarshallling invoiceCorrelation ", errUnmarshal)
	}
	// generating notification
	bankCodeFinancedInvoice, errorGetBankCode := getBankCode(stub, UTCRefNo)
	if errorGetBankCode != nil {
		return shim.Error(errorGetBankCode.Error())
	}

	if Status == "PURGED" {
		fmt.Println("STATUS RECEIVED IS PURGED ")
		if len(invoiceCorrlnnReal.MyImpact) > 0 {
			for i := 0; i < len(invoiceCorrlnnReal.MyImpact); i++ {

				utcRefNoImpact := invoiceCorrlnnReal.MyImpact[i]
				fmt.Println("  \n\n >>>>>>>>. Fetching correlation : " + utcRefNoImpact)
				// removeing co-relation

				invceCorrlnduplicate := InvoiceCorrelation{}

				invoiceCorrlationBytes, err := fetchData(stub, utcRefNoImpact, "invoiceCorrelation")
				if err != nil {
					fmt.Println("Error occurred while fetching document from utcRefBankMapping with key : " + utcRefNoImpact)
					return shim.Error("Error occurred while fetching document from utcRefBankMapping with key  : " + utcRefNoImpact + " " + err.Error())
				}
				errUnmarshl := json.Unmarshal(invoiceCorrlationBytes, &invceCorrlnduplicate)
				if errUnmarshl != nil {
					fmt.Println("Error occurred while unmarshallling invoiceCorrelation ", errUnmarshl)
					return shim.Error("Error occurred while unmarshallling invoiceCorrelation ::  " + errUnmarshl.Error())
				}
				//removing from ImpacteddBy
				impacedBy := invceCorrlnduplicate.ImpactedBy

				ind := -1
				for index := range impacedBy {
					if impacedBy[index] == UTCRefNo {
						ind = index
					}
				}

				if ind != -1 {
					// Remove the element at index i from array.
					copy(impacedBy[ind:], impacedBy[ind+1:]) // Shift a[ind+1:] left one index.
					impacedBy[len(impacedBy)-1] = ""         // Erase last element (write zero value).
					impacedBy = impacedBy[:len(impacedBy)-1] // Truncate slice.
				}

				invceCorrlnduplicate.ImpactedBy = impacedBy

				marshallCorrelation, errorMarshal := json.Marshal(invceCorrlnduplicate)
				if errorMarshal != nil {
					fmt.Println("Errro occurred while marshallling invoiceCorrln ", errorMarshal)
				}
				errorinvoiceCorrelation := insertData(&stub, utcRefNoImpact, "invoiceCorrelation", marshallCorrelation)
				//raise shim error message if insertion fails.
				if errorinvoiceCorrelation != nil {
					fmt.Println("Insertion failed of invoiceCorrelationMarshalled !!!!!!", errorinvoiceCorrelation)
					return shim.Error(errorinvoiceCorrelation.Error())
				}

				// generating notification
				bankCode, errorGetBankCode := getBankCode(stub, utcRefNoImpact)
				if errorGetBankCode != nil {
					return shim.Error(errorGetBankCode.Error())
				}

				notificatn := &NotificationOnSameInvoice{
					DocumentName: "Notification",
					Key:          UUID,
					MessageText:  "Duplicate invoice with invoice # " + invoiceNo + " against UTC ref # " + utcRefNoImpact + " has been purged by the other bank in the UTC system. Please reprocess this invoice.",
					CreatedOn:    generatedOn,
					Type:         getTeamType().OPERATIONAL,
				}

				notificatnMarshalled, errorMarshal := json.Marshal(notificatn)
				if errorMarshal != nil {
					fmt.Println("Marshal failed for notificatn Document !!!!!!", errorMarshal)
					return shim.Error(errorMarshal.Error())
				}
				fmt.Println("Marshalled notificatnArray: ", notificatnMarshalled)

				errorInsert := insertData(&stub, notificatn.Key, "notification_"+bankCode, notificatnMarshalled)
				//raise shim error message if insertion fails.
				if errorInsert != nil {
					fmt.Println("Insertion failed of notificatn !!!!!!", errorInsert)
					return shim.Error(errorInsert.Error())
				}
				RaiseEventData(stub, "EventOnRaiseNotification")
			}

			invoiceCorrlnnReal.MyImpact = []string{}
			fmt.Println("Invoice correlation MyImpact is empty now !!!!!! ")
			marshallCorrelation, errorMarshal := json.Marshal(invoiceCorrlnnReal)
			if errorMarshal != nil {
				fmt.Println("Errro occurred while marshallling invoiceCorrln ", errorMarshal)
			}

			fmt.Println("\n\n >>>>>>> inserting in correlation >>>>  " + UTCRefNo)
			errorinvoiceCorrelation := insertData(&stub, UTCRefNo, "invoiceCorrelation", marshallCorrelation)
			//raise shim error message if insertion fails.
			if errorinvoiceCorrelation != nil {
				fmt.Println("Insertion failed of invoiceCorrelation Marshalled !!!!!! ", errorinvoiceCorrelation)
				return shim.Error(errorinvoiceCorrelation.Error())
			}
		} else if len(invoiceCorrlnnReal.ImpactedBy) > 0 {
			for i := 0; i < len(invoiceCorrlnnReal.ImpactedBy); i++ {

				utcRefImpactedBy := invoiceCorrlnnReal.ImpactedBy[i]
				fmt.Println("  \n\n >>>>>>>>. invoiceCorrlnnReal  : " + utcRefImpactedBy)
				// removeing co-relation

				invceCorrlnduplicate := InvoiceCorrelation{}

				invoiceCorrlationBytes, err := fetchData(stub, utcRefImpactedBy, "invoiceCorrelation")
				if err != nil {
					fmt.Println("Error occurred while fetching document from utcRefBankMapping with key : " + utcRefImpactedBy)
					return shim.Error("Error occurred while fetching document from utcRefBankMapping with key  : " + utcRefImpactedBy + " " + err.Error())
				}
				errUnmarshl := json.Unmarshal(invoiceCorrlationBytes, &invceCorrlnduplicate)
				if errUnmarshl != nil {
					fmt.Println("Error occurred while unmarshallling invoiceCorrelation ", errUnmarshl)
					return shim.Error("Error occurred while unmarshallling invoiceCorrelation ::  " + errUnmarshl.Error())
				}
				//removing from muimpact
				myimpact := invceCorrlnduplicate.MyImpact

				ind := -1
				for index := range myimpact {
					if myimpact[index] == UTCRefNo {
						ind = index
					}
				}

				if ind != -1 {
					// Remove the element at index i from array.
					copy(myimpact[ind:], myimpact[ind+1:]) // Shift a[ind+1:] left one index.
					myimpact[len(myimpact)-1] = ""         // Erase last element (write zero value).
					myimpact = myimpact[:len(myimpact)-1]  // Truncate slice.
				}

				invceCorrlnduplicate.MyImpact = myimpact

				marshallCorrelation, errorMarshal := json.Marshal(invceCorrlnduplicate)
				if errorMarshal != nil {
					fmt.Println("Errro occurred while marshallling invoiceCorrln ", errorMarshal)
				}
				errorinvoiceCorrelation := insertData(&stub, utcRefImpactedBy, "invoiceCorrelation", marshallCorrelation)
				//raise shim error message if insertion fails.
				if errorinvoiceCorrelation != nil {
					fmt.Println("Insertion failed of invoiceCorrelationMarshalled !!!!!!", errorinvoiceCorrelation)
					return shim.Error(errorinvoiceCorrelation.Error())
				}
				fmt.Println("\n\n >>>>>>>>>  Opposite bank purged this invoice , so imapctBy has been removed !!!")

			}
			fmt.Println("Invoice correlation ImapctedBy si empty now !!!!!! ")
			invoiceCorrlnnReal.ImpactedBy = []string{}

			marshallCorrelation, errorMarshal := json.Marshal(invoiceCorrlnnReal)
			if errorMarshal != nil {
				fmt.Println("Errro occurred while marshallling invoiceCorrln ", errorMarshal)
			}

			fmt.Println("\n\n >>>>>>>   inserting in correlation >>>>  " + UTCRefNo)
			errorinvoiceCorrelation := insertData(&stub, UTCRefNo, "invoiceCorrelation", marshallCorrelation)
			//raise shim error message if insertion fails.
			if errorinvoiceCorrelation != nil {
				fmt.Println("Insertion failed of invoiceCorrelation Marshalled !!!!!! ", errorinvoiceCorrelation)
				return shim.Error(errorinvoiceCorrelation.Error())
			}
		} else {
			fmt.Println("STATUS RECEIVED IS PURGED , NO DUPLICATES FOUND . MYIMPACTS ARE EMPTY .CORRELATIONS AND NOTFICATION NOT UPDATED AND GENERATED RESPECTIVELY")
		}
	}
	if Status == "FINANCED" || Status == "SECURITIZED" {

		if len(invoiceCorrlnnReal.MyImpact) > 0 {
			for i := 0; i < len(invoiceCorrlnnReal.MyImpact); i++ {
				utcRefNoImpact := invoiceCorrlnnReal.MyImpact[i]

				// generating notification
				bankCode, errorGetBankCode := getBankCode(stub, utcRefNoImpact)
				if errorGetBankCode != nil {
					return shim.Error(errorGetBankCode.Error())
				}

				//fetch existing document
				docCollection := "documents" + "_" + bankCode
				documentData, errorGetDocumentData := getDocumentData(stub, utcRefNoImpact, docCollection)
				if errorGetDocumentData != nil {
					return shim.Error(errorGetDocumentData.Error())
				}

				if documentData.Status == "FINANCED" && Status == "FINANCED" {
					fmt.Println("\n\n >>>>>> BOTH ARE FINANCED >>>>>>>>>>>>>>>>>>>>>>>>>>")
					fmt.Println(" >>>>>> documentData.Status is finanaced >>>>>>>>>>>>>>>>>>>>>>>>>>", documentData.Status)
					notificatn := &NotificationOnSameInvoice{
						DocumentName: "Notification",
						Key:          UUID,
						MessageText:  "Duplicate invoice with invoice # " + invoiceNo + " against UTC ref # " + utcRefNoImpact + " has also been FINANCED by some other bank in the UTC system.Please take appropriate action.",
						CreatedOn:    generatedOn,
						Type:         getTeamType().GOVERNANCE,
					}

					notificatnMarshalled, errorMarshal := json.Marshal(notificatn)
					if errorMarshal != nil {
						fmt.Println("Marshal failed for notificatn Document !!!!!!", errorMarshal)
						return shim.Error(errorMarshal.Error())
					}
					fmt.Println("Marshalled notificatnArray: ", notificatnMarshalled)

					errorInsert := insertData(&stub, notificatn.Key, "notification_"+bankCode, notificatnMarshalled)
					//raise shim error message if insertion fails.
					if errorInsert != nil {
						fmt.Println("Insertion failed of notificatn !!!!!!", errorInsert)
						return shim.Error(errorInsert.Error())
					}

					notificatn = &NotificationOnSameInvoice{
						DocumentName: "Notification",
						Key:          UUID,
						MessageText:  "Duplicate invoice with invoice # " + invoiceNo + " against UTC ref # " + UTCRefNo + " has also been " + Status + " by some other bank in the UTC system.Please take appropriate action.",
						CreatedOn:    generatedOn,
						Type:         getTeamType().GOVERNANCE,
					}

					notificatnMarshalled, errorMarshal = json.Marshal(notificatn)
					if errorMarshal != nil {
						fmt.Println("Marshal failed for notificatn Document !!!!!!", errorMarshal)
						return shim.Error(errorMarshal.Error())
					}
					fmt.Println("Marshalled notificatnArray: ", notificatnMarshalled)

					errorInsert = insertData(&stub, notificatn.Key, "notification_"+bankCodeFinancedInvoice, notificatnMarshalled)
					//raise shim error message if insertion fails.
					if errorInsert != nil {
						fmt.Println("Insertion failed of notificatn !!!!!!", errorInsert)
						return shim.Error(errorInsert.Error())
					}

				} else {
					notificatn := &NotificationOnSameInvoice{
						DocumentName: "Notification",
						Key:          UUID,
						MessageText:  "Duplicate invoice with invoice # " + invoiceNo + " against UTC ref # " + utcRefNoImpact + " has been " + Status + " by some other bank in the UTC system.Please take appropriate action.",
						CreatedOn:    generatedOn,
						Type:         getTeamType().OPERATIONAL,
					}

					notificatnMarshalled, errorMarshal := json.Marshal(notificatn)
					if errorMarshal != nil {
						fmt.Println("Marshal failed for notificatn Document !!!!!!", errorMarshal)
						return shim.Error(errorMarshal.Error())
					}
					fmt.Println("Marshalled notificatnArray: ", notificatnMarshalled)

					errorInsert := insertData(&stub, notificatn.Key, "notification_"+bankCode, notificatnMarshalled)
					//raise shim error message if insertion fails.
					if errorInsert != nil {
						fmt.Println("Insertion failed of notificatn !!!!!!", errorInsert)
						return shim.Error(errorInsert.Error())
					}

				}

			}
			RaiseEventData(stub, "EventOnRaiseNotification")
		} else if len(invoiceCorrlnnReal.ImpactedBy) > 0 {
			for i := 0; i < len(invoiceCorrlnnReal.ImpactedBy); i++ {
				utcRefNoImpact := invoiceCorrlnnReal.ImpactedBy[i]

				// generating notification
				bankCode, errorGetBankCode := getBankCode(stub, utcRefNoImpact)
				if errorGetBankCode != nil {
					return shim.Error(errorGetBankCode.Error())
				}

				//fetch existing document
				docCollection := "documents" + "_" + bankCode
				documentData, errorGetDocumentData := getDocumentData(stub, utcRefNoImpact, docCollection)
				if errorGetDocumentData != nil {
					return shim.Error(errorGetDocumentData.Error())
				}

				if documentData.Status == "FINANCED" && Status == "FINANCED" {
					fmt.Println("\n\n >>>>>> BOTH ARE FINANCED >>>>>>>>>>>>>>>>>>>>>>>>>>")
					fmt.Println(" >>>>>> documentData.Status is finanaced >>>>>>>>>>>>>>>>>>>>>>>>>>", documentData.Status)
					notificatn := &NotificationOnSameInvoice{
						DocumentName: "Notification",
						Key:          UUID,
						MessageText:  "Duplicate invoice with invoice # " + invoiceNo + " against UTC ref # " + utcRefNoImpact + " has also been " + Status + " by some other bank in the UTC system.Please take appropriate action.",
						CreatedOn:    generatedOn,
						Type:         getTeamType().GOVERNANCE,
					}

					notificatnMarshalled, errorMarshal := json.Marshal(notificatn)
					if errorMarshal != nil {
						fmt.Println("Marshal failed for notificatn Document !!!!!!", errorMarshal)
						return shim.Error(errorMarshal.Error())
					}
					fmt.Println("Marshalled notificatnArray: ", notificatnMarshalled)

					errorInsert := insertData(&stub, notificatn.Key, "notification_"+bankCode, notificatnMarshalled)
					//raise shim error message if insertion fails.
					if errorInsert != nil {
						fmt.Println("Insertion failed of notificatn !!!!!!", errorInsert)
						return shim.Error(errorInsert.Error())
					}

					notificatn = &NotificationOnSameInvoice{
						DocumentName: "Notification",
						Key:          UUID,
						MessageText:  "Duplicate invoice with invoice # " + invoiceNo + " against UTC ref # " + UTCRefNo + " has also been " + Status + " by some other bank in the UTC system.Please take appropriate action.",
						CreatedOn:    generatedOn,
						Type:         getTeamType().GOVERNANCE,
					}

					notificatnMarshalled, errorMarshal = json.Marshal(notificatn)
					if errorMarshal != nil {
						fmt.Println("Marshal failed for notificatn Document !!!!!!", errorMarshal)
						return shim.Error(errorMarshal.Error())
					}
					fmt.Println("Marshalled notificatnArray: ", notificatnMarshalled)

					errorInsert = insertData(&stub, notificatn.Key, "notification_"+bankCodeFinancedInvoice, notificatnMarshalled)
					//raise shim error message if insertion fails.
					if errorInsert != nil {
						fmt.Println("Insertion failed of notificatn !!!!!!", errorInsert)
						return shim.Error(errorInsert.Error())
					}
				} else {
					notificatn := &NotificationOnSameInvoice{
						DocumentName: "Notification",
						Key:          UUID,
						MessageText:  "Duplicate invoice with invoice # " + invoiceNo + " against UTC ref # " + utcRefNoImpact + " has been " + Status + " by some other bank in the UTC system.Please take appropriate action.",
						CreatedOn:    generatedOn,
						Type:         getTeamType().OPERATIONAL,
					}

					notificatnMarshalled, errorMarshal := json.Marshal(notificatn)
					if errorMarshal != nil {
						fmt.Println("Marshal failed for notificatn Document !!!!!!", errorMarshal)
						return shim.Error(errorMarshal.Error())
					}
					fmt.Println("Marshalled notificatnArray : ", notificatnMarshalled)

					errorInsert := insertData(&stub, notificatn.Key, "notification_"+bankCode, notificatnMarshalled)
					//raise shim error message if insertion fails.
					if errorInsert != nil {
						fmt.Println("Insertion failed of notificatn !!!!!!", errorInsert)
						return shim.Error(errorInsert.Error())
					}
				}
			}
			RaiseEventData(stub, "EventOnRaiseNotification")
		} else {
			fmt.Println("STTAUS RECEIVED IS EITHER FINANCED R SECURITIZED . NO DUPLICATES FOUND . MYIMPACTS AR EMPTY . CORRELATIONS AND NOTFICATION NOT UPDATED AND GENERATED RESPECTIVELY")
		}
	}
	// RaiseEventData(stub, "EventOnRaiseNotification")
	return shim.Success(nil)
}
