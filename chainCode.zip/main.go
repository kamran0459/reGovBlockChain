package main

import (
	"encoding/json"
	"fmt"

	"github.com/hyperledger/fabric/core/chaincode/lib/cid"
	"github.com/hyperledger/fabric/core/chaincode/shim"
	pb "github.com/hyperledger/fabric/protos/peer"
)

type UTCChainCode struct {
}

var logger = shim.NewLogger("UTC")

func main() {
	fmt.Println("UTC ChainCode Started")
	err := shim.Start(new(UTCChainCode))
	if err != nil {
		fmt.Println("Error starting UTC chaincode: ", err)
	}
}

func (t *UTCChainCode) Init(stub shim.ChaincodeStubInterface) pb.Response {
	fmt.Println("UTC ChainCode Initiated")

	_, args := stub.GetFunctionAndParameters()
	fmt.Printf("Init: %v", args)
	if len(args[0]) <= 0 {
		return shim.Error("MSP Mapping information is required for initiating the chain code")
	}

	var MSPListUnmarshaled []MSPList
	err := json.Unmarshal([]byte(args[0]), &MSPListUnmarshaled)

	if err != nil {
		return shim.Error("An error occurred while Unmarshiling MSPMapping: " + err.Error())
	}
	MSPMappingJSONasBytes, err := json.Marshal(MSPListUnmarshaled)
	if err != nil {
		return shim.Error("An error occurred while Marshiling MSPMapping :" + err.Error())
	}
	_Key := "MSPMapping"
	err = stub.PutState(_Key, []byte(MSPMappingJSONasBytes))
	if err != nil {
		return shim.Error("An error occurred while inserting MSPMapping:" + err.Error())
	}
	return shim.Success(nil)
}

func (t *UTCChainCode) Invoke(stub shim.ChaincodeStubInterface) pb.Response {

	certOrgType, err := cid.GetMSPID(stub)
	if err != nil {
		return shim.Error("Enrolment mspid Type invalid!!! " + err.Error())
	}
	fmt.Println("MSP:" + certOrgType)

	orgType, err := getOrgTypeByMSP(stub, string(certOrgType))
	if err != nil {
		return shim.Error(err.Error())
	}

	function, _ := stub.GetFunctionAndParameters()
	fmt.Println("Invoke is running for function: " + function)

	args, errTrans := getArguments(stub)
	if errTrans != nil {
		return shim.Error(errTrans.Error())
	}
	fmt.Println("Arguments Loaded Successfully!!")

	connection := hypConnect{}
	connection.Connection = stub

	if orgType == "BANK" {
		switch functionName := function; functionName {

		case "addDataStructure":
			return t.addDataStructure(connection, args, "addDataStructure")

		case "submitDocument":
			return t.submitDocument(connection, args, "submitDocument")

		case "updateDocumentStatus":
			return t.updateDocumentStatus(connection, args, "updateDocumentStatus")

		case "submitOCRResult":
			return t.submitOCRResult(connection, args, "submitOCRResult")

			//raiseNotificationOnPurge
		case "raiseNotificationOnPurge":
			return t.raiseNotificationOnPurge(connection, args, "raiseNotificationOnPurge")

		case "resubmitDocument":
			return t.resubmitDocument(connection, args, "resubmitDocument")

		case "stampRuleResult":
			return t.stampRuleResult(connection, args, "stampRuleResult")

		case "stampRuleSet":
			return t.stampRuleSet(connection, args, "stampRuleSet")

		case "reprocessRuleExecution":
			return t.reprocessRuleExecution(connection, args, "reprocessRuleExecution")

		case "getDocument":
			return t.getDocument(connection, args, "getDocument")

		case "getRules":
			return t.getRules(connection, args, "getRules")

		case "GetDataByKey":
			return t.GetDataByKey(connection, args, "GetDataByKey")

		case "GetBatchDetail":
			return t.GetBatchDetail(connection, args, "GetBatchDetail")

		case "addComplainceSetting":
			return t.addComplainceSetting(connection, args, "addComplainceSetting")
			//addComplainceSetting
		default:
			logger.Warning("Invoke did not find function: " + function)
			return shim.Error("Received unknown function invocation: " + function)
		}
	} else {
		return shim.Error("Invalid MSP: " + orgType)
	}

}

func insertDataAndRaiseEvent(stub shim.ChaincodeStubInterface, key string, eventType string, data []byte) error {

	err := stub.PutState(key, data)
	if err != nil {
		return err
	}
	logger.Debug("Successfully Put State for Key: " + key)

	err = stub.SetEvent(eventType, []byte(data))
	if err != nil {
		return err
	}
	logger.Debug("Successfully Raised Chain Code for Event Type: " + eventType)
	return nil
}

func (t *UTCChainCode) addDataStructure(stub hypConnect, args []string, functionName string) pb.Response {
	logger.Debug("addDataStructure: %v", args)

	if len(args) <= 0 {
		return shim.Error("Invalid Arguments")
	}

	var attributes []Attribute
	errorUnmarshal := json.Unmarshal([]byte(args[4]), &attributes)
	if errorUnmarshal != nil {
		logger.Critical("%s\n", errorUnmarshal)
		return shim.Error("Invalid Argument for fields !!!!!!" + errorUnmarshal.Error())
	}
	fmt.Println("Unmarshaled attributes: ", attributes)

	//prepare data structure
	metaInfo := &MetaInfo{
		DocumentName:  "mappingfield",
		Name:          sanitize(args[0], "string").(string),
		Description:   sanitize(args[1], "string").(string),
		Type:          sanitize(args[2], "string").(string),
		SubType:       sanitize(args[3], "string").(string),
		AttributeList: attributes,
	}
	metaInfo.Key = metaInfo.Type + "-" + metaInfo.SubType

	/*
		//check existing
		existingDSBytes, errorFetch := fetchData(stub, metaInfo.Key, "metaInfo")
		if errorFetch != nil {
			fmt.Println("Something went wrong for DS fetchData !!!!!!", errorFetch)
			return shim.Error(errorFetch.Error())
		} else if len(existingDSBytes) != 0 {
			return shim.Error("Data structure for " + metaInfo.Key + " already exists.")
		}
	*/

	//marshal prepared data structure
	metaInfoBytes, errorMarshal := json.Marshal(metaInfo)
	if errorMarshal != nil {
		logger.Critical("%s\n", errorMarshal.Error())
		return shim.Error(errorMarshal.Error())
	}
	//insert marshalled data structure
	errorInsert := insertData(&stub, metaInfo.Key, "metaInfo", metaInfoBytes)
	if errorInsert != nil {
		logger.Critical("%s\n", errorInsert.Error())
		return shim.Error(errorInsert.Error())
	}
	logger.Debug("addDataStructure function executed successfully")
	_, _ = RaiseEventData(stub, "EventOnAddDataStructure")
	return shim.Success(nil)
}

func (t *UTCChainCode) updateDocumentStatus(stub hypConnect, args []string, functionName string) pb.Response {
	fmt.Println("updateDocumentStatus: ", args)

	if len(args) <= 0 {
		return shim.Error("Invalid Arguments")
	}

	var status = getStatus()
	var processingStatus = getProcessingStatus()

	var documentList []DocumentListElement
	errorUnmarshal := json.Unmarshal([]byte(args[0]), &documentList)
	if errorUnmarshal != nil {
		fmt.Println("Invalid Argument for documentList !!!!!!", errorUnmarshal)
		return shim.Error("Invalid Argument for documentList !!!!!!" + errorUnmarshal.Error())
	} else if len(documentList) == 0 {
		return shim.Error("Document List is not valid")
	}
	fmt.Println("Unmarshaled documentList: ", documentList)

	updateDocumentStatusArgs := &ParamsUpdateDocumentStatus{
		DocumentList: documentList,
	}

	for _, data := range updateDocumentStatusArgs.DocumentList {
		bankCode, errorGetBankCode := getBankCode(stub, data.UTCRefNo)
		if errorGetBankCode != nil {
			return shim.Error(errorGetBankCode.Error())
		}

		//fetch existing document
		docCollection := "documents" + "_" + bankCode
		documentData, errorGetDocumentData := getDocumentData(stub, data.UTCRefNo, docCollection)
		if errorGetDocumentData != nil {
			return shim.Error(errorGetDocumentData.Error())
		}

		fmt.Println("incoming status: ", data.Status)
		fmt.Println("before document status: ", documentData.ProcessingStatus, documentData.Status)

		batchFetchDataBytes, errorFetch := GetBatchDetailByIDOrUpdateStatus(stub, documentData.BatchNo, bankCode, 0, documentData.UTCRefNo, documentData.ProcessingStatus)
		if errorFetch != nil {
			fmt.Println("No batch found with key ", documentData.BatchNo)
			return shim.Error(errorFetch.Error())
		}
		var existingBatchData DocumentBatch
		//unMarshaling Batch Data
		fmt.Println("Found Batch number", batchFetchDataBytes)
		errorUnmarshal := json.Unmarshal(batchFetchDataBytes, &existingBatchData)
		if errorUnmarshal != nil {
			fmt.Println("Unmarshaling failed for existing document data !!!!!!", errorUnmarshal)
		}
		fmt.Println("existingBatchData Batch Data", existingBatchData)
		shouldSecureOrFinance := true
		for _, UTCRefs := range existingBatchData.UTCRefList {
			if UTCRefs.DocumentStatus != processingStatus.ProcessCompleted {
				shouldSecureOrFinance = false
				break
			}
		}
		switch data.Status {
		case status.Purged: // UNDERPROCESS OR SECURITIZED --> PURGED
			if documentData.Status == status.UnderProcess || documentData.Status == status.Securitized {
				documentData.Status = data.Status
			} else {
				return shim.Error("Cannot update status because current status is: " + documentData.Status)
			}
		case status.Rejected: // UNDERPROCESS --> REJECTED OR SECURITIZED
			if documentData.Status == status.UnderProcess {
				documentData.Status = data.Status
			} else {
				return shim.Error("Cannot update status because current status is: " + documentData.Status)
			}
		case status.Securitized: // UNDERPROCESS --> REJECTED OR SECURITIZED
			if documentData.Status == status.UnderProcess {
				if shouldSecureOrFinance {
					documentData.Status = data.Status
				} else {
					return shim.Error("All the documents in the batch does not have status : " + processingStatus.ProcessCompleted)
				}
			} else {
				return shim.Error("Cannot update status because current status is: " + documentData.Status)
			}
		case status.Financed: // UNDERPROCESS AND PROCESSCOMPLETED --> FINANCED
			if documentData.Status == status.UnderProcess && documentData.ProcessingStatus == processingStatus.ProcessCompleted {
				if shouldSecureOrFinance {
					documentData.Status = data.Status
				} else {
					return shim.Error("All the documents in the batch does not have status : " + processingStatus.ProcessCompleted)
				}
			} else {
				return shim.Error("Cannot update status because current status is: " + documentData.Status + " and processing status is: " + documentData.ProcessingStatus)
			}
		default:
			return shim.Error("Invalid Status Provided")
		}

		fmt.Println("after document status: ", documentData.ProcessingStatus, documentData.Status)
		//marshal final document data
		documentDataMarshalled, errorMarshal := json.Marshal(documentData)
		if errorMarshal != nil {
			fmt.Println("Marshal failed for documentData !!!!!!", errorMarshal)
			return shim.Error(errorMarshal.Error())
		}
		fmt.Println("Marshalled documentData: ", documentDataMarshalled)
		//insert marshaled document data
		errorInsert := insertData(&stub, documentData.Key, docCollection, documentDataMarshalled)
		//raise shim error message if insertion fails.
		if errorInsert != nil {
			fmt.Println("Insertion failed of documentDataMarshalled !!!!!!", errorInsert)
			return shim.Error(errorInsert.Error())
		}
	}

	fmt.Println("updateDocumentStatus function executed successfully")
	_, _ = RaiseEventData(stub, "EventOnDocumentStatusChange")
	return shim.Success(nil)
}

func (t *UTCChainCode) stampRuleSet(stub hypConnect, args []string, functionName string) pb.Response {
	fmt.Println("stampRuleResult: ", args[0])

	_Key := sanitize(args[0], "string").(string)
	_DocName := "ruleset"

	fmt.Println("stampRuleResult next step 1: ")

	var _manualRange []ManualRange
	unMerr := json.Unmarshal([]byte(args[9]), &_manualRange)
	if unMerr != nil {
		fmt.Printf("%s\n", unMerr)
		return shim.Error("Invalid Argument for _manfFiles !!!!!!" + unMerr.Error())
	}

	var _rules []Rules
	unMerrR := json.Unmarshal([]byte(args[10]), &_rules)
	if unMerrR != nil {
		fmt.Printf("%s\n", unMerrR)
		return shim.Error("Invalid Argument for Rules !!!!!!" + unMerrR.Error())
	}

	fmt.Println("stampRuleResult next step 2: ")

	ruleSet := &RuleSet{
		Key:             _Key,
		DocumentName:    _DocName,
		Country:         sanitize(args[3], "string").(string),
		Industry:        sanitize(args[4], "string").(string),
		DocumentType:    sanitize(args[5], "string").(string),
		DocumentSubType: sanitize(args[6], "string").(string),
		PassRange:       sanitize(args[7], "string").(string),
		FailRange:       sanitize(args[8], "string").(string),
		ManualRange:     _manualRange,
		Rules:           _rules,
	}
	fmt.Println("stampRuleResult next step 4: ")
	ruleSetJSONToByte, err := json.Marshal(ruleSet)
	if err != nil {
		return shim.Error(err.Error())
	}
	fmt.Println("stampRuleResult next step 5: ")

	fmt.Print("ruleSetJSONToByte", ruleSetJSONToByte)
	err = insertData(&stub, _Key, "ruleset", ruleSetJSONToByte)
	if err != nil {
		return shim.Error(err.Error())
	}
	logger.Debug("stampRuleSet function executed successfully.")

	_, err = RaiseEventData(stub, "EventOnStampRuleSet")
	if err != nil {
		return shim.Error(err.Error())
	}
	return shim.Success(nil)
}

func (t *UTCChainCode) reprocessRuleExecution(stub hypConnect, args []string, functionName string) pb.Response {
	fmt.Println("reprocessRuleExecution: ", args)

	if len(args) <= 0 {
		return shim.Error("Invalid Arguments")
	}

	var status = getStatus()
	var processingStatus = getProcessingStatus()

	reprocessRuleExecutionArgs := &ParamsReprocessRuleExecution{
		UTCRefNo:   sanitize(args[0], "string").(string),
		DocumentNo: sanitize(args[1], "string").(string),
	}

	bankCode, errorGetBankCode := getBankCode(stub, reprocessRuleExecutionArgs.UTCRefNo)
	if errorGetBankCode != nil {
		return shim.Error(errorGetBankCode.Error())
	}

	//fetch existing document
	docCollection := "documents" + "_" + bankCode
	documentData, errorGetDocumentData := getDocumentData(stub, reprocessRuleExecutionArgs.UTCRefNo, docCollection)
	if errorGetDocumentData != nil {
		return shim.Error(errorGetDocumentData.Error())
	}

	fmt.Println("before document status: ", documentData.ProcessingStatus, documentData.Status)

	if documentData.Status == status.UnderProcess && documentData.ProcessingStatus == processingStatus.ProcessCompleted {
		documentData.ProcessingStatus = processingStatus.Completed
		documentData.RuleResults = nil
		documentData.UTCStatus = ""
		documentData.Progress = 0
		documentData.Duplicate = 0
		documentData.RuleResultIDs = nil

		fmt.Println("Reset rule related fields")

	} else {
		return shim.Error("Document cannot be reprocessed as the current status of the document is " + documentData.ProcessingStatus)
	}

	fmt.Println("after document status: ", documentData.ProcessingStatus, documentData.Status)
	//marshal final document data
	documentDataMarshalled, errorMarshal := json.Marshal(documentData)
	if errorMarshal != nil {
		fmt.Println("Marshal failed for documentData !!!!!!", errorMarshal)
		return shim.Error(errorMarshal.Error())
	}
	fmt.Println("Marshalled documentData: ", documentDataMarshalled)
	//insert marshaled document data
	errorInsert := insertData(&stub, documentData.Key, docCollection, documentDataMarshalled)
	//raise shim error message if insertion fails.
	if errorInsert != nil {
		fmt.Println("Insertion failed of documentDataMarshalled !!!!!!", errorInsert)
		return shim.Error(errorInsert.Error())
	}

	fmt.Println("reprocessRuleExecution function executed successfully.")
	_, _ = RaiseEventData(stub, "EventOnReprocessRuleExecution")
	return shim.Success(nil)
}

func (t *UTCChainCode) getRules(stub hypConnect, args []string, functionName string) pb.Response {
	fmt.Println("getRules: ", args)
	return shim.Success(nil)
}

func (t *UTCChainCode) GetDataByKey(stub hypConnect, args []string, functionName string) pb.Response {
	fmt.Println("GetDataByKey: ", args)

	if len(args[0]) <= 0 {
		return shim.Error("Invalid Argument")
	}
	_Key := sanitize(args[0], "string").(string)
	_Collection := sanitize(args[1], "string").(string)
	trnxAsBytes, err := fetchData(stub, _Key, _Collection)
	if err != nil {
		fmt.Println("No Data found with Key: " + _Key)
		return shim.Error("No Data found with key: " + err.Error())
	}
	if trnxAsBytes == nil {
		return shim.Error("No data found with key: ")
	}
	return shim.Success(trnxAsBytes)
}

func (t *UTCChainCode) GetBatchDetail(stub hypConnect, args []string, functionName string) pb.Response {
	if len(args) == 0 {
		return shim.Error("No Batch key provided.")
	}
	_batchKey := sanitize(args[0], "string").(string)
	_orgCode := sanitize(args[1], "string").(string)
	docBatchCollection := "documentBatch" + "_" + _orgCode
	batchFetchDataBytes, errorFetch := fetchData(stub, _batchKey, docBatchCollection)
	//Verifying the Error
	fmt.Println("Found Batch number", batchFetchDataBytes)
	if errorFetch != nil {
		fmt.Println("Something went wrong while fetching batch data !!!!!!", errorFetch)
		return shim.Error(errorFetch.Error())
	}
	if batchFetchDataBytes == nil {
		return shim.Error("No data found with batch key: " + _batchKey)
	}
	return shim.Success(batchFetchDataBytes)
}

func GetBatchDetailByIDOrUpdateStatus(stub hypConnect, _batchKey string, _orgCode string, returnType int, ref string, status string) ([]byte, error) {
	docBatchCollection := "documentBatch" + "_" + _orgCode
	batchFetchDataBytes, errorFetch := fetchData(stub, _batchKey, docBatchCollection)
	if returnType == 0 {
		return batchFetchDataBytes, errorFetch
	}
	var existingBatchData DocumentBatch
	//unMarshaling Batch Data
	fmt.Println("Found Batch number", batchFetchDataBytes)
	errorUnmarshal := json.Unmarshal(batchFetchDataBytes, &existingBatchData)
	if errorUnmarshal != nil {
		fmt.Println("Unmarshaling failed for existing document data !!!!!!", errorUnmarshal)
	}
	fmt.Println("existingBatchData Batch Data", existingBatchData)
	for i, utcRefObj := range existingBatchData.UTCRefList {
		if utcRefObj.UTCRefNo == ref {
			existingBatchData.UTCRefList[i].DocumentStatus = status
		}
	}
	fmt.Println("prepared documentBatchData: ", existingBatchData)
	//marshal prepared batch data
	documentBatchDataMarshalled, errorMarshal := json.Marshal(existingBatchData)
	return documentBatchDataMarshalled, errorMarshal
}

func addBatchIndexAndStatus(list []UTCRef, index int, status string) []UTCRef {
	for i := 0; i < len(list); i++ {
		list[i].BatchIndex = index
		if status != "" {
			list[i].DocumentStatus = status
		}
	}
	return list
}

func addDocumentStatusToBatch(list []UTCRef, status string) []UTCRef {
	for i := 0; i < len(list); i++ {
		list[i].DocumentStatus = status
	}
	return list
}

func (t *UTCChainCode) addComplainceSetting(stub hypConnect, args []string, functionName string) pb.Response {
	fmt.Println("Arguments : ", args)

	key := "COMPLAINCE-POLICY"

	policyType := sanitize(args[0], "string").(string)
	docName := "complainceSettings"

	var fields []map[string]interface{}
	unMarshallfields := json.Unmarshal([]byte(args[1]), &fields)
	if unMarshallfields != nil {
		fmt.Printf("%s\n", unMarshallfields)
		return shim.Error("Invalid Argument for unMarshall fields !!!!!!" + unMarshallfields.Error())
	}

	complainceSetting := &ComplainceSetting{
		Key:         key,
		DocumentNo:  docName,
		PolicyType:  policyType,
		Fields:      fields,
		ProcessDate: sanitize(args[2], "string").(string),
		Status:      sanitize(args[3], "string").(string),
	}
	ComplainceSettingJSONToByte, err := json.Marshal(complainceSetting)
	if err != nil {
		return shim.Error(err.Error())
	}

	fmt.Print("ComplainceSettingJSONToByte :: ", ComplainceSettingJSONToByte)
	err = insertData(&stub, key, "complainceSetting", ComplainceSettingJSONToByte)
	if err != nil {
		return shim.Error(err.Error())
	}
	logger.Debug("ComplainceSetting function executed successfully.")

	_, err = RaiseEventData(stub, "EventOnComplainceSetting")
	if err != nil {
		return shim.Error(err.Error())
	}
	return shim.Success(nil)
}
