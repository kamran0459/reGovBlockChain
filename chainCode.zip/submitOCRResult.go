package main

import (
	"encoding/json"
	"fmt"

	"github.com/hyperledger/fabric/core/chaincode/shim"
	pb "github.com/hyperledger/fabric/protos/peer"
)

func (t *UTCChainCode) submitOCRResult(stub hypConnect, args []string, functionName string) pb.Response {
	fmt.Println("submitOCRResult: ", args)

	if len(args) <= 0 {
		return shim.Error("Invalid Arguments")
	}

	var ocrList []map[string]interface{}
	errorUnmarshal := json.Unmarshal([]byte(args[1]), &ocrList)
	if errorUnmarshal != nil {
		fmt.Println("Invalid Argument for ocrList !!!!!!", errorUnmarshal)
		return shim.Error("Invalid Argument for ocrList !!!!!!" + errorUnmarshal.Error())
	} else if len(ocrList) == 0 {
		return shim.Error("OCR Data is not valid")
	}
	fmt.Println("Unmarshaled ocrList: ", ocrList)

	submitOCRResultArgs := &ParamsSubmitOCRResult{
		BatchNo: sanitize(args[0], "string").(string),
		OCRData: ocrList,
		OrgCode: sanitize(args[2], "string").(string),
	}

	var shouldRaiseEventOnMisMatch bool
	var shouldRaiseEventOCRCompleted bool
	var EventOnDataCorrected bool
	var doesBatchHasNonExisting bool
	// Fetching the Batch
	docBatchCollection := "documentBatch" + "_" + submitOCRResultArgs.OrgCode
	var existingBatchData DocumentBatch
	batchFetchDataBytes, errorFetch := fetchData(stub, submitOCRResultArgs.BatchNo, docBatchCollection)
	//Verifying the Error
	fmt.Println("Found Batch number", batchFetchDataBytes)
	if errorFetch != nil {
		fmt.Println("Something went wrong for utcRefNo fetchData !!!!!!", errorFetch)
		return shim.Error(errorFetch.Error())
	}
	if len(batchFetchDataBytes) == 0 {
		return shim.Error("Provided Batch doesn't exists.")
	} else {
		//unMarshaling Batch Data
		fmt.Println("Found Batch number", batchFetchDataBytes)
		errorUnmarshal = json.Unmarshal(batchFetchDataBytes, &existingBatchData)
		if errorUnmarshal != nil {
			fmt.Println("Unmarshaling failed for existing document data !!!!!!", errorUnmarshal)
		}
		fmt.Println("existingBatchData Batch Data", existingBatchData)
		var utcRefArray []string
		for _, utcRefNoObj := range existingBatchData.UTCRefList {
			if utcRefNoObj.DocumentNo == "" {
				utcRefArray = append(utcRefArray, utcRefNoObj.UTCRefNo)
			}
		}
		if len(utcRefArray) == 0 {
			doesBatchHasNonExisting = true
		}
		fmt.Println("Non existingBatchData Batch Data", utcRefArray)
		/**
		  Analyzing which document is already in batch
		*/
		//if len(existingBatchData.UTCRefList) < len(submitOCRResultArgs.OCRData) {
		var indexOfNoExisting = 0
		for _, OCRRequestObj := range submitOCRResultArgs.OCRData {
			var isFound = false
			var utcExisting string
			for _, utcRefNoObj := range existingBatchData.UTCRefList {
				fmt.Println("Inside 2nd loop")
				fmt.Println("")
				fmt.Println("")
				fmt.Println("")
				//TODO: Handle empty or undefined Document Number provided in Request
				if OCRRequestObj["documentNo"] == utcRefNoObj.DocumentNo {
					isFound = true
					utcExisting = utcRefNoObj.UTCRefNo
					break
				}
			}
			if isFound {
				OCRRequestObj["isDocAvailableInBatch"] = true
				OCRRequestObj["UTCRefNo"] = utcExisting
				utcExisting = ""
			} else {
				if indexOfNoExisting >= len(utcRefArray) || len(utcRefArray) == 0 {
					return shim.Error("OCR Documents are more than the Batch Documents")
				}
				OCRRequestObj["isDocAvailableInBatch"] = false
				OCRRequestObj["UTCRefNo"] = utcRefArray[indexOfNoExisting]
				indexOfNoExisting = indexOfNoExisting + 1
			}
		}
		//} else {
		//	shim.Error("Number of OCR result Provided is more than the submitted ORC.")
		//}
		/**
		Finally Manupulating the OCR data
		*/
		var processingStatus = getProcessingStatus()
		getType := getType()
		for _, docOCRData := range submitOCRResultArgs.OCRData {
			utcRefNo := docOCRData["UTCRefNo"].(string)
			fmt.Println("docOCRData: ", docOCRData)
			if docOCRData["isDocAvailableInBatch"] == true {
				bankCode, errorGetBankCode := getBankCode(stub, utcRefNo)
				if errorGetBankCode != nil {
					return shim.Error(errorGetBankCode.Error())
				}

				//fetch existing document
				docCollection := "documents" + "_" + bankCode
				documentData, errorGetDocumentData := getDocumentData(stub, utcRefNo, docCollection)
				if errorGetDocumentData != nil {
					return shim.Error(errorGetDocumentData.Error())
				}
				fmt.Println("fetched documentData: ", documentData)
				//TODO:// May be replicated in other case as well
				if documentData.ProcessingStatus != processingStatus.Pending {
					return shim.Error("Status is not " + processingStatus.Pending + " for the document: " + documentData.Key)
				}

				//fetch data structure for incoming OCR data
				dsKey := documentData.DocumentType + "-" + documentData.DocumentSubType
				ds, errorGetDataStructure := getDataStructure(stub, dsKey)
				if errorGetDataStructure != nil {
					return shim.Error(errorGetDataStructure.Error())
				}
				fmt.Println("fetched ds: ", ds)

				//map incoming OCR data to DS
				mappedOCRData, _ := mapDataStructure(docOCRData, ds.AttributeList)
				fmt.Println("mappedOCRData ------", mappedOCRData)
				documentData.OCRData = mappedOCRData
				documentData.Type = getType.BOTH
				documentData.FileHash = existingBatchData.BatchFileImage[0].Hash
				documentData.MismatchFields, documentData.ProcessingData = computeMismatchAndProcessing(documentData.OCRData, documentData.ElectronicData, ds.AttributeList, documentData.Override)

				fmt.Println("mismatchFields: ", documentData.MismatchFields)
				fmt.Println("processingData: ", documentData.ProcessingData)

				if len(documentData.MismatchFields) == 0 {
					documentData.ProcessingStatus = processingStatus.Completed
					shouldRaiseEventOCRCompleted = true
				} else if len(documentData.MismatchFields) != 0 && documentData.Override {
					documentData.ProcessingStatus = processingStatus.Corrected
					EventOnDataCorrected = true
				} else {
					documentData.ProcessingStatus = processingStatus.Mismatched
					shouldRaiseEventOnMisMatch = true
				}

				//marshal prepared document data
				documentDataMarshalled, errorMarshal := json.Marshal(documentData)
				if errorMarshal != nil {
					fmt.Println("Marshal failed for documentData !!!!!!", errorMarshal)
					return shim.Error(errorMarshal.Error())
				}
				fmt.Println("Marshalled documentData: ", documentDataMarshalled)
				//insert marshaled document data
				errorInsert := insertData(&stub, documentData.Key, docCollection, documentDataMarshalled)
				//raise shim error message if insertion fails.
				if errorInsert != nil {
					fmt.Println("Insertion failed of documentDataMarshalled !!!!!!", errorInsert)
					return shim.Error(errorInsert.Error())
				}
			} else {
				if doesBatchHasNonExisting {
					return shim.Error("No Pending Document in Batch" + existingBatchData.BatchNo + "waiting for ODR data")
				}
				//prepare utcRef bank mapping data
				utcRefBankMapping := &UTCRefBankMapping{
					DocumentName: "utcrefbankmapping",
					Key:          "MAP_" + utcRefNo,
					BankCode:     submitOCRResultArgs.OrgCode,
					DocumentNo:   docOCRData["documentNo"].(string),
					BatchNo:      submitOCRResultArgs.BatchNo,
				}
				//marshal prepared utcRef bank mapping data
				utcRefBankMappingMarshalled, errorMarshal := json.Marshal(utcRefBankMapping)
				if errorMarshal != nil {
					fmt.Println("Marshal failed for utcRefBankMapping !!!!!!", errorMarshal)
					return shim.Error(errorMarshal.Error())
				}
				fmt.Println("Marshalled utcRefBankMapping: ", utcRefBankMappingMarshalled)
				//insert marshalled utcRef bank mapping data
				errorInsert := insertData(&stub, utcRefBankMapping.Key, "utcRefBankMapping", utcRefBankMappingMarshalled)
				//raise shim error message if insertion fails.
				if errorInsert != nil {
					fmt.Println("Insertion failed of utcRefBankMappingMarshalled !!!!!!", errorInsert)
					return shim.Error(errorInsert.Error())
				}
				var status = getStatus()
				documentData := &Document{
					DocumentName:     "document",
					Key:              utcRefNo,
					DocumentNo:       docOCRData["documentNo"].(string),
					UTCRefNo:         utcRefNo,
					Customer:         existingBatchData.Customer,
					BatchNo:          submitOCRResultArgs.BatchNo,
					DocumentType:     docOCRData["documentType"].(string),
					DocumentSubType:  docOCRData["documentSubType"].(string),
					Override:         false,
					Status:           status.UnderProcess,
					ProcessingStatus: processingStatus.Mismatched,
					UploadedOn:       getEpochTime(),
					UploadedBy:       submitOCRResultArgs.OrgCode,
					FileHash:         existingBatchData.BatchFileImage[0].Hash,
				}
				//fetch data structure for incoming OCR data
				dsKey := documentData.DocumentType + "-" + documentData.DocumentSubType
				ds, errorGetDataStructure := getDataStructure(stub, dsKey)
				if errorGetDataStructure != nil {
					return shim.Error(errorGetDataStructure.Error())
				}
				fmt.Println("fetched ds: ", ds)

				//map incoming OCR data to DS
				mappedOCRData, _ := mapDataStructure(docOCRData, ds.AttributeList)
				fmt.Println("mappedOCRData ------", mappedOCRData)

				documentData.OCRData = mappedOCRData
				documentData.Type = getType.OCR
				documentData.MismatchFields, documentData.ProcessingData = computeMismatchAndProcessing(documentData.OCRData, documentData.ElectronicData, ds.AttributeList, documentData.Override)

				fmt.Println("mismatchFields: ", documentData.MismatchFields)
				fmt.Println("processingData: ", documentData.ProcessingData)

				if len(documentData.MismatchFields) == 0 {
					documentData.ProcessingStatus = processingStatus.Completed
					shouldRaiseEventOCRCompleted = true
				} else if len(documentData.MismatchFields) != 0 && documentData.Override {
					documentData.ProcessingStatus = processingStatus.Corrected
				} else {
					documentData.ProcessingStatus = processingStatus.Mismatched
					shouldRaiseEventOnMisMatch = true
				}
				// Updating Document number in batch
				for i, utcRefNoObj := range existingBatchData.UTCRefList {
					if utcRefNoObj.UTCRefNo == utcRefNo {
						existingBatchData.UTCRefList[i].DocumentNo = documentData.DocumentNo
						fmt.Println("after", utcRefNoObj)
					}
				}
				docCollection := "documents" + "_" + submitOCRResultArgs.OrgCode
				documentDataMarshalled, errorMarshal := json.Marshal(documentData)
				if errorMarshal != nil {
					fmt.Println("Marshal failed for documentData !!!!!!", errorMarshal)
					return shim.Error(errorMarshal.Error())
				}
				fmt.Println("Marshalled documentData: ", documentDataMarshalled)
				//insert marshalled document data
				errorInsert = insertData(&stub, documentData.Key, docCollection, documentDataMarshalled)
				//raise shim error message if insertion fails.
				if errorInsert != nil {
					fmt.Println("Insertion failed of documentDataMarshalled !!!!!!", errorInsert)
					return shim.Error(errorInsert.Error())
				}

				fmt.Println("prepared documentBatchData: ", existingBatchData)
				//marshal prepared batch data
				documentBatchDataMarshalled, errorMarshal := json.Marshal(existingBatchData)
				if errorMarshal != nil {
					fmt.Println("Marshal failed for documentBatchData !!!!!!", errorMarshal)
					return shim.Error(errorMarshal.Error())
				}
				fmt.Println("Marshalled documentBatchData: ", documentBatchDataMarshalled)
				//insert marshalled batch data
				errorInsertBatchData := insertData(&stub, existingBatchData.Key, docBatchCollection, documentBatchDataMarshalled)
				//raise shim error message if insertion fails.
				if errorInsertBatchData != nil {
					fmt.Println("Insertion failed of documentBatchDataMarshalled !!!!!!", errorInsertBatchData)
					return shim.Error(errorInsertBatchData.Error())
				}
				shouldRaiseEventOnMisMatch = true
			}
		}

	}

	fmt.Println("OCR DATA", submitOCRResultArgs.OCRData)
	fmt.Println("submitOCRResult function executed successfully")
	if shouldRaiseEventOnMisMatch {
		_, _ = RaiseEventData(stub, "EventOnDataMismatch")
	}
	if shouldRaiseEventOCRCompleted {
		_, _ = RaiseEventData(stub, "shouldRaiseEventOCRCompleted")
	}
	if EventOnDataCorrected {
		_, _ = RaiseEventData(stub, "EventOnDataCorrected")
	}

	return shim.Success(nil)
}
