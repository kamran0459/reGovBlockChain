package main

type StatusList struct {
	UnderProcess string
	Purged       string
	Rejected     string
	Securitized  string
	Financed     string
}
type TeamType struct {
	OPERATIONAL string
	GOVERNANCE  string
}
type ProcessingStatusList struct {
	Pending          string
	Completed        string
	Mismatched       string
	Corrected        string
	ProcessCompleted string
	RuleProcessing   string
}

type DocumentTypeList struct {
	ELECTRONIC string
	OCR        string
	BOTH       string
}
type rulesType struct {
	FIELDMATCH string
	DUPLICATE  string
}
type PolicyType struct {
	COMPLETE string
	MATCHING string
	NONE     string
}

func getStatus() StatusList {
	returnVal := &StatusList{
		UnderProcess: "UNDERPROCESS",
		Purged:       "PURGED",
		Rejected:     "REJECTED",
		Securitized:  "SECURITIZED",
		Financed:     "FINANCED",
	}
	return *returnVal
}

func getProcessingStatus() ProcessingStatusList {
	returnVal := &ProcessingStatusList{
		Pending:          "OCRPENDING",
		Completed:        "OCRCOMPLETED",
		Mismatched:       "OCRMISMATCHED",
		Corrected:        "CORRECTED",
		ProcessCompleted: "RULEPROCESSCOMPLETED",
		RuleProcessing:   "RULEPROCESSING",
	}
	return *returnVal
}

func getType() DocumentTypeList {
	returnVal := &DocumentTypeList{
		ELECTRONIC: "ELECTRONIC",
		OCR:        "OCR",
		BOTH:       "BOTH",
	}
	return *returnVal
}
func getRuleType() rulesType {
	returnVal := &rulesType{
		FIELDMATCH: "fieldsMatch",
		DUPLICATE:  "DUPLICATE",
	}
	return *returnVal
}
func getPolicyType() PolicyType {
	returnVal := &PolicyType{
		COMPLETE: "COMPLETE",
		MATCHING: "MATCHING",
		NONE:     "NONE",
	}
	return *returnVal
}
func getTeamType() TeamType {
	returnVal := &TeamType{
		OPERATIONAL: "OPS",
		GOVERNANCE:  "GOV",
	}
	return *returnVal
}
