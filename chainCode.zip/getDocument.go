package main

import (
	"encoding/json"
	"fmt"

	"github.com/hyperledger/fabric/core/chaincode/shim"
	pb "github.com/hyperledger/fabric/protos/peer"
)

func (t *UTCChainCode) getDocument(stub hypConnect, args []string, functionName string) pb.Response {
	fmt.Println("getDocument: ", args)
	if len(args) <= 0 {
		return shim.Error("Invalid Argument")
	}
	_orgCode := sanitize(args[0], "string").(string)
	_utcRefNo := sanitize(args[1], "string").(string)
	docCollection := "documents" + "_" + _orgCode
	//check existing
	docDataBytes, errorFetch := fetchData(stub, _utcRefNo, docCollection)
	if errorFetch != nil {
		fmt.Println("Something went wrong for utcRefNo fetchData !!!!!!", errorFetch)
		return shim.Error(errorFetch.Error())
	}
	if docDataBytes == nil {
		return shim.Error("No data found with key: ")
	}
	// unmarshal document
	var docData Document
	err := json.Unmarshal([]byte(docDataBytes), &docData)
	if err != nil {
		fmt.Printf("%s", err)
		return shim.Error("Invalid Argument !!!!!!" + err.Error())
	}
	var ruleResultArray []RuleResult
	for i := 0; i < len(docData.RuleResultIDs); i++ {
		// fetch
		ruleResultBytes, errorFetch := fetchData(stub, docData.RuleResultIDs[i], "documentRulesResult")
		if errorFetch != nil {
			fmt.Println("Something went wrong for utcRefNo fetchData !!!!!!", errorFetch)
			return shim.Error(errorFetch.Error())
		}
		// unmarshal
		var ruleResult RuleResult
		err := json.Unmarshal([]byte(ruleResultBytes), &ruleResult)
		if err != nil {
			fmt.Printf("%s", err)
			return shim.Error("Invalid Argument !!!!!!" + err.Error())
		}
		ruleResultArray = append(ruleResultArray, ruleResult)
	}
	docData.RuleResults = ruleResultArray
	docData.BankCode = _orgCode
	// marshal Updated document
	docDataAsBytes, err := json.Marshal(docData)
	if err != nil {
		return shim.Error("SubmitDocument marshal error" + err.Error())
	}

	return shim.Success(docDataAsBytes)
}
