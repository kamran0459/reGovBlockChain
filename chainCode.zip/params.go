package main

type ParamsSubmitDocument struct {
	OrgCode         string                   `json:"orgCode"`
	BatchNo         string                   `json:"batchNo"`
	BatchFileImage  BatchFileImage           `json:"batchFileImage"`
	DocumentCount   int                      `json:"documentCount"`
	DocumentType    string                   `json:"documentType"`
	DocumentSubType string                   `json:"documentSubType"`
	Customer        Customer                 `json:"customer"`
	ElectronicData  []map[string]interface{} `json:"electronicData"`
	UTCRefList      []UTCRef                 `json:"UTCRefList"`
	Override        bool                     `json:"override"`
	UploadType      string                   `json:"uploadType"`
	BankRefNumbers  []string                 `json:"bankRefNumbers"`
}

type ParamsSubmitOCRResult struct {
	OrgCode string                   `json:"orgCode"`
	BatchNo string                   `json:"batchNo"`
	OCRData []map[string]interface{} `json:"OCRData"`
}

type ParamsResubmitDocument struct {
	BatchNo     string        `json:"batchNo"`
	CorrectData []CorrectData `json:"correctData"`
}

type ParamsUpdateDocumentStatus struct {
	DocumentList []DocumentListElement `json:"documentList"`
}

type DocumentListElement struct {
	DocumentNo  string `json:"documentNo"`
	UTCRefNo    string `json:"UTCRefNo"`
	Status      string `json:"status"`
	ProcessedBy string `json:"processedBy"`
	ProcessDate string `json:"processDate"`
}

// type purgeNotificationParam struct {
// 	DocumentList []DocumentListElement `json:"documentList"`
// 	UUID         string                `json:"uuid"`
// 	GeneratedOn  string                `json:"generatedOn"`
// }
type ParamsReprocessRuleExecution struct {
	DocumentNo string `json:"documentNo"`
	UTCRefNo   string `json:"UTCRefNo"`
}
