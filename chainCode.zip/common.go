package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"strings"
	"time"

	"github.com/hyperledger/fabric/core/chaincode/shim"
)

func insertData(stub *hypConnect, key string, privateCollection string, data []byte) error {

	err := stub.Connection.PutPrivateData(privateCollection, key, data)
	if err != nil {
		return err
	}

	event := eventDataFormat{}
	event.Key = key
	event.Collection = privateCollection
	stub.EventList = stub.AddEvent(event)

	fmt.Println("Successfully Put State for Key: " + key + " and Private Collection " + privateCollection)
	return nil
}
func fetchData(stub hypConnect, key string, privateCollection string) ([]byte, error) {
	bytes, err := stub.Connection.GetPrivateData(privateCollection, key)
	if err != nil {
		return nil, err
	}
	return bytes, nil
}

func getArguments(stub shim.ChaincodeStubInterface) ([]string, error) {
	transMap, err := stub.GetTransient()
	if err != nil {
		return nil, err
	}
	if _, ok := transMap["PrivateArgs"]; !ok {
		return nil, errors.New("PrivateArgs must be a key in the transient map")
	}
	fmt.Printf("Arguments: %v", transMap)
	generalInput := string(transMap["PrivateArgs"])
	retVal := strings.Split(generalInput, "|")
	return retVal, nil
}
func getOrgTypeByMSP(stub shim.ChaincodeStubInterface, MSP string) (string, error) {

	MSPMappingAsBytes, err := stub.GetState("MSPMapping")
	if err != nil {
		return "", err
	}

	if err != nil {
		fmt.Println("MSPMapping - Failed to get state MSP mapping information." + err.Error())
		return "", err
	} else if MSPMappingAsBytes != nil {
		fmt.Println("MSPMapping - This data Fetched from Transactions.")
		var MSPListUnmarshaled []MSPList

		err := json.Unmarshal(MSPMappingAsBytes, &MSPListUnmarshaled)
		if err != nil {
			fmt.Println("MSPMapping-Failed to UnMarshal state.")
			return "", err
		}
		fmt.Printf("Unmarshaled: %v", MSPListUnmarshaled)
		for i := 0; i < len(MSPListUnmarshaled); i++ {
			if MSPListUnmarshaled[i].MSP == MSP {
				fmt.Println("OrgType for MSP " + MSP + " is " + MSPListUnmarshaled[i].OrgType)
				return MSPListUnmarshaled[i].OrgType, nil
			}
		}
	}
	return "", nil
}

func getEpochTime() int64 {
	return time.Now().Unix()
}
func getMax(n1, n2 int) int {
	if n1 > n2 {
		return n1
	}
	return n2
}

func getUTCRefNo(utcRefList []UTCRef, documentNo string) string {
	var temp string
	for _, utcRef := range utcRefList {
		if utcRef.DocumentNo == documentNo {
			temp = utcRef.UTCRefNo
			break
		}
	}
	return temp
}

//function for fetching bank code using utcRefNo from utcRefBankMapping collection
func getBankCode(stub hypConnect, utcRefNo string) (string, error) {
	utcRefBankMappingBytes, errorFetch := fetchData(stub, "MAP_"+utcRefNo, "utcRefBankMapping")
	if errorFetch != nil {
		fmt.Printf("%s\n", errorFetch)
		return "", errorFetch
	} else if len(utcRefBankMappingBytes) == 0 {
		return "", errors.New("no utcRefBankMapping found for utcRefNo: " + utcRefNo)
	}
	//unmarshal fetched utcRefBankMapping data
	var utcRefBankMapping UTCRefBankMapping
	errorUnmarshal := json.Unmarshal(utcRefBankMappingBytes, &utcRefBankMapping)
	if errorUnmarshal != nil {
		fmt.Println("Somthing went wrong while unmarshalling utcRefBankMapping !!!!!!", errorUnmarshal)
		return "", errorUnmarshal
	}
	fmt.Println("Unmarshaled utcRefBankMapping : ", utcRefBankMapping)
	fmt.Println("getBankCode >>>> ")
	return utcRefBankMapping.BankCode, nil
}

//function for fetching existing document using utcRefNo from private org collection
func getDocumentData(stub hypConnect, key string, collection string) (*Document, error) {
	documentDataBytes, errorFetch := fetchData(stub, key, collection)
	if errorFetch != nil {
		fmt.Println("Something went wrong for document fetchData !!!!!!", errorFetch)
		return nil, errorFetch
	} else if len(documentDataBytes) == 0 {
		fmt.Println("No document found !!!!!!")
		return nil, errors.New("No document found for this utcRef " + key)
	}
	//unmarshal fetched document data
	var documentData Document
	errorUnmarshal := json.Unmarshal(documentDataBytes, &documentData)
	if errorUnmarshal != nil {
		fmt.Println("Unmarshaling failed for existing document !!!!!! ", errorUnmarshal)
		return nil, errorUnmarshal
	}
	fmt.Println("\n\n\n Unmarshaled documentData >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> : ", documentData)
	return &documentData, nil
}

func getDataStructure(stub hypConnect, key string) (*MetaInfo, error) {
	dsDataBytes, errorFetch := fetchData(stub, key, "metaInfo")
	if errorFetch != nil {
		fmt.Println("Something went wrong for datastructure fetchData !!!!!!", errorFetch)
		return nil, errorFetch
	} else if len(dsDataBytes) == 0 {
		fmt.Println("No datastructure found !!!!!!")
		return nil, errors.New("No datastructure found for referenced DataStructure REF: " + key)
	}
	//unmarshal fetched document data structure
	var dsData MetaInfo
	errorUnmarshal := json.Unmarshal(dsDataBytes, &dsData)
	if errorUnmarshal != nil {
		fmt.Println("Unmarshaling failed for existing datastructure !!!!!! ", errorUnmarshal)
		return nil, errorUnmarshal
	}
	fmt.Println("Unmarshaled datastructure: ", dsData)
	return &dsData, nil
}

//mapDataStructure function for reconciliation logic
func mapDataStructure(data map[string]interface{}, attributes []Attribute) (map[string]interface{}, error) {
	fmt.Println("mapDataStructure data: ", data)
	fmt.Println("mapDataStructure attributes: ", attributes)
	// reconciliation Logic
	temp := make(map[string]interface{})
	for _, value := range attributes {
		fmt.Println("value mapping", value.Mapping)
		fmt.Println("data value mapping", data[value.Mapping])
		if val, ok := data[value.Mapping]; ok {
			temp[value.Mapping] = val
		} else {
			temp[value.Mapping] = nil
		}
	}
	return temp, nil
}

//RaiseEventData
func RaiseEventData(stub hypConnect, eventName string, args ...interface{}) (string, error) {

	var eventList generalEventStruct
	eventList.EventName = eventName
	eventList.EventList = stub.EventList
	eventList.AdditionalData = args
	eventJSONasBytes, err2 := json.Marshal(eventList)
	if err2 != nil {
		return "", err2
	}
	fmt.Println("Event raised: " + eventName)
	//fmt.Println("\neventJSONasBytes : ", eventList.EventName+"\n")
	mEventName := eventList.EventName
	err3 := stub.Connection.SetEvent("chainCodeEvent", []byte(eventJSONasBytes))
	if err3 != nil {
		return "", err3
	}
	var err4 error
	err4 = nil
	return mEventName, err4

}
