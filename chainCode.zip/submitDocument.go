package main

import (
	"encoding/json"
	"fmt"
	"reflect"

	"github.com/hyperledger/fabric/core/chaincode/shim"
	pb "github.com/hyperledger/fabric/protos/peer"
)

//This method is used for both new documents submission
func (t *UTCChainCode) submitDocument(stub hypConnect, args []string, functionName string) pb.Response {
	fmt.Println("submitDocument Args List =>>>>>>>>>>> : ", args, args[10], args[11])

	if len(args) <= 0 {
		return shim.Error("Invalid Arguments")
	}

	var status = getStatus()
	var processingStatus = getProcessingStatus()

	var batchFileImage BatchFileImage
	errorUnmarshal := json.Unmarshal([]byte(args[2]), &batchFileImage)
	if errorUnmarshal != nil {
		fmt.Println("Invalid Argument for batchFileImage !!!!!!", errorUnmarshal)
		return shim.Error("Invalid Argument for batchFileImage !!!!!!" + errorUnmarshal.Error())
	}
	fmt.Println("Unmarshaled batchFileImage: ", batchFileImage)

	var batchImagesExists bool
	if reflect.DeepEqual(BatchFileImage{}, batchFileImage) {
		batchImagesExists = true
	}

	fmt.Println("batchImagesExists batchImagesExists: ", batchImagesExists)

	var customer Customer
	errorUnmarshal = json.Unmarshal([]byte(args[6]), &customer)
	if errorUnmarshal != nil {
		fmt.Println("Invalid Argument for customer !!!!!!", errorUnmarshal)
		return shim.Error("Invalid Argument for customer !!!!!!" + errorUnmarshal.Error())
	}
	fmt.Println("Unmarshaled customer: ", customer)

	if reflect.DeepEqual(Customer{}, customer) {
		return shim.Error("Customer data is invalid")
	}

	var utcRefList []UTCRef
	errorUnmarshal = json.Unmarshal([]byte(args[7]), &utcRefList)
	if errorUnmarshal != nil {
		fmt.Println("Invalid Argument for utcRefList !!!!!!", errorUnmarshal)
		return shim.Error("Invalid Argument for utcRefList !!!!!!" + errorUnmarshal.Error())
	}
	fmt.Println("Unmarshaled utcRefList: ", utcRefList)

	var documentList []map[string]interface{}
	errorUnmarshal = json.Unmarshal([]byte(args[8]), &documentList)
	if errorUnmarshal != nil {
		fmt.Println("Invalid Argument for documentList !!!!!!", errorUnmarshal)
		return shim.Error("Invalid Argument for documentList !!!!!!" + errorUnmarshal.Error())
	}
	fmt.Println("Unmarshaled documentList: ", documentList)

	var bankRefNumbersList []string
	errorUnmarshal = json.Unmarshal([]byte(args[11]), &bankRefNumbersList)
	if errorUnmarshal != nil {
		fmt.Println("Invalid Argument for documentList !!!!!!", errorUnmarshal)
		return shim.Error("Invalid Argument for documentList !!!!!!" + errorUnmarshal.Error())
	}
	fmt.Println("Unmarshaled documentList: ", bankRefNumbersList)

	//Sanitize all the received arguments in structure say submitDocumentArgs
	submitDocumentArgs := &ParamsSubmitDocument{
		OrgCode:         sanitize(args[0], "string").(string),
		BatchNo:         sanitize(args[1], "string").(string),
		BatchFileImage:  batchFileImage,
		DocumentCount:   sanitize(args[3], "int").(int),
		DocumentType:    sanitize(args[4], "string").(string),
		DocumentSubType: sanitize(args[5], "string").(string),
		Customer:        customer,
		UTCRefList:      utcRefList,
		ElectronicData:  documentList,
		Override:        sanitize(args[9], "bool").(bool),
		UploadType:      sanitize(args[10], "string").(string),
		BankRefNumbers:  bankRefNumbersList,
	}

	if len(submitDocumentArgs.ElectronicData) == 0 && batchImagesExists {
		return shim.Error("Please provide Electronic Data or Image Data!")
	}

	if len(submitDocumentArgs.ElectronicData) > 0 {
		if len(submitDocumentArgs.ElectronicData) != submitDocumentArgs.DocumentCount {
			return shim.Error("Document Count does not match with documents provided!")
		}
	}
	docBatchCollection := "documentBatch" + "_" + submitDocumentArgs.OrgCode
	//fetch the batch data using submitDocumentArgs.BatchNo from the appropriate bank private collection
	batchDataBytes, errorFetch := fetchData(stub, submitDocumentArgs.BatchNo, docBatchCollection)
	if errorFetch != nil {
		fmt.Println("Something went wrong for BatchNo fetchData !!!!!!", errorFetch)
		return shim.Error(errorFetch.Error())
	}

	//prepate batch data
	var documentBatchData *DocumentBatch
	if len(batchDataBytes) == 0 {
		refList := addDocumentStatusToBatch(submitDocumentArgs.UTCRefList, processingStatus.Pending)
		documentBatchData = &DocumentBatch{
			Key:            submitDocumentArgs.BatchNo,
			DocumentName:   "documentbatch",
			BatchNo:        submitDocumentArgs.BatchNo,
			BatchIndex:     0,
			UTCRefList:     refList,
			BatchFileImage: []BatchFileImage{submitDocumentArgs.BatchFileImage},
			Customer:       submitDocumentArgs.Customer,
			DocumentCount:  submitDocumentArgs.DocumentCount,
			UploadedOn:     getEpochTime(),
			UploadedBy:     submitDocumentArgs.OrgCode,
			UploadType:     submitDocumentArgs.UploadType,
			BankRefNumbers: submitDocumentArgs.BankRefNumbers,
			BankCode:       submitDocumentArgs.OrgCode,
		}
	} else {
		fmt.Println("Batch exists !!!!!!!!!")
		// If already batch is there then checking if all the invoices in batch have Rule Processed status if yes then no further invoice can be added
		batchFetchDataBytes, errorFetch := GetBatchDetailByIDOrUpdateStatus(stub, submitDocumentArgs.BatchNo, submitDocumentArgs.OrgCode, 0, "", "")
		if errorFetch != nil {
			fmt.Println("No batch found with key ", submitDocumentArgs.BatchNo)
			return shim.Error(errorFetch.Error())
		}
		var existingBatchData DocumentBatch
		//unMarshaling Batch Data
		fmt.Println("Found Batch number", batchFetchDataBytes)
		errorUnmarshal := json.Unmarshal(batchFetchDataBytes, &existingBatchData)
		if errorUnmarshal != nil {
			fmt.Println("Unmarshaling failed for existing document data !!!!!!", errorUnmarshal)
		}
		fmt.Println("existingBatchData Batch Data", existingBatchData)
		shouldSecureOrFinance := true
		for _, UTCRefs := range existingBatchData.UTCRefList {
			if UTCRefs.DocumentStatus != processingStatus.ProcessCompleted {
				shouldSecureOrFinance = false
				break
			}
		}
		if shouldSecureOrFinance {
			return shim.Error("Rules are processed on all the documents in the batch no further document can be added.")
		}
		// End ::::::: If already batch is there then checking if all the invoices in batch have Rule Processed status if yes then no further invoice can be added
		if len(submitDocumentArgs.ElectronicData) == 0 {
			var existingBatchData DocumentBatch
			batchFetchDataBytes, errorFetch := fetchData(stub, submitDocumentArgs.BatchNo, docBatchCollection)
			if errorFetch != nil {
				fmt.Println("Something went wrong for utcRefNo fetchData !!!!!!", errorFetch)
				return shim.Error(errorFetch.Error())
			} else if len(batchFetchDataBytes) != 0 {
				//this would be very unlikely that the same UUID is assigned to other document no.
				errorUnmarshal = json.Unmarshal(batchFetchDataBytes, &existingBatchData)
				if errorUnmarshal != nil {
					fmt.Println("Unmarshaling failed for existing document data !!!!!!", errorUnmarshal)
				}
				for _, utcRefNoObj := range existingBatchData.UTCRefList {
					if utcRefNoObj.UTCRefNo == submitDocumentArgs.UTCRefList[0].UTCRefNo {
						return shim.Error("A document with reference " + utcRefNoObj.UTCRefNo + " already associcated with the batch " + existingBatchData.BatchNo)
					}
				}
			}
		}
		errorUnmarshal = json.Unmarshal(batchDataBytes, &documentBatchData)
		if errorUnmarshal != nil {
			fmt.Println("Unmarshal failed of existing documentBatchData !!!!!!", errorUnmarshal)
			return shim.Error(errorUnmarshal.Error())
		}
		documentBatchData.BatchFileImage = append(documentBatchData.BatchFileImage, submitDocumentArgs.BatchFileImage)
		documentBatchData.BatchIndex = documentBatchData.BatchIndex + 1
		refList := addBatchIndexAndStatus(submitDocumentArgs.UTCRefList, documentBatchData.BatchIndex, processingStatus.Pending)
		documentBatchData.UTCRefList = append(documentBatchData.UTCRefList, refList...)
		documentBatchData.DocumentCount = documentBatchData.DocumentCount + len(submitDocumentArgs.ElectronicData)
	}
	getType := getType()
	incomingType := ""
	if !batchImagesExists && len(submitDocumentArgs.ElectronicData) > 0 {
		incomingType = getType.BOTH
	} else if !batchImagesExists {
		incomingType = getType.OCR
	} else if len(submitDocumentArgs.ElectronicData) > 0 {
		incomingType = getType.ELECTRONIC
	}
	documentBatchData.Type = incomingType
	fmt.Println("prepared documentBatchData: ", documentBatchData)
	//marshal prepared batch data
	documentBatchDataMarshalled, errorMarshal := json.Marshal(documentBatchData)
	if errorMarshal != nil {
		fmt.Println("Marshal failed for documentBatchData !!!!!!", errorMarshal)
		return shim.Error(errorMarshal.Error())
	}
	fmt.Println("Marshalled documentBatchData: ", documentBatchDataMarshalled)
	//insert marshalled batch data
	errorInsert := insertData(&stub, documentBatchData.Key, docBatchCollection, documentBatchDataMarshalled)
	//raise shim error message if insertion fails.
	if errorInsert != nil {
		fmt.Println("Insertion failed of documentBatchDataMarshalled !!!!!!", errorInsert)
		return shim.Error(errorInsert.Error())
	}

	for _, docElectronicData := range submitDocumentArgs.ElectronicData {
		fmt.Println("document electronic data: ", docElectronicData)
		//get the UUID of the document
		utcRefNo := getUTCRefNo(submitDocumentArgs.UTCRefList, docElectronicData["documentNo"].(string))
		//if no UTCRefNo found based on the documentNo then raise shim error
		fmt.Println("utcRefNo found: ", utcRefNo)
		if utcRefNo == "" {
			return shim.Error("No utcRefNo found based on the document number")
		}

		docCollection := "documents" + "_" + submitDocumentArgs.OrgCode
		//check existing
		docDataBytes, errorFetch := fetchData(stub, utcRefNo, docCollection)
		if errorFetch != nil {
			fmt.Println("Something went wrong for utcRefNo fetchData !!!!!!", errorFetch)
			return shim.Error(errorFetch.Error())
		} else if len(docDataBytes) != 0 {
			//this would be very unlikely that the same UUID is assigned to other document no.
			var existingDocData Document
			errorUnmarshal = json.Unmarshal(docDataBytes, &existingDocData)
			if errorUnmarshal != nil {
				fmt.Println("Unmarshaling failed for existing document data !!!!!!", errorUnmarshal)
			}
			return shim.Error("A document with reference " + utcRefNo + " already associcated with the batch " + existingDocData.BatchNo)
		}

		//prepare utcRef bank mapping data
		utcRefBankMapping := &UTCRefBankMapping{
			DocumentName: "utcrefbankmapping",
			Key:          "MAP_" + utcRefNo,
			BankCode:     submitDocumentArgs.OrgCode,
			DocumentNo:   docElectronicData["documentNo"].(string),
			BatchNo:      submitDocumentArgs.BatchNo,
		}
		//marshal prepared utcRef bank mapping data
		utcRefBankMappingMarshalled, errorMarshal := json.Marshal(utcRefBankMapping)
		if errorMarshal != nil {
			fmt.Println("Marshal failed for utcRefBankMapping !!!!!!", errorMarshal)
			return shim.Error(errorMarshal.Error())
		}
		fmt.Println("Marshalled utcRefBankMapping: ", utcRefBankMappingMarshalled)
		//insert marshalled utcRef bank mapping data
		errorInsert = insertData(&stub, utcRefBankMapping.Key, "utcRefBankMapping", utcRefBankMappingMarshalled)
		//raise shim error message if insertion fails.
		if errorInsert != nil {
			fmt.Println("Insertion failed of utcRefBankMappingMarshalled !!!!!!", errorInsert)
			return shim.Error(errorInsert.Error())
		}

		//fetch data structure for incoming electronic data
		dsKey := submitDocumentArgs.DocumentType + "-" + submitDocumentArgs.DocumentSubType
		ds, errorGetDataStructure := getDataStructure(stub, dsKey)
		if errorGetDataStructure != nil {
			return shim.Error(errorGetDataStructure.Error())
		}
		fmt.Println("fetched ds:::::::::: ", ds, submitDocumentArgs.UploadType)

		//map incoming electronic data to DS
		mappedElectronicData, _ := mapDataStructure(docElectronicData, ds.AttributeList)
		fmt.Println("mappedElectronicData ------", mappedElectronicData)

		//prepare document data
		documentData := &Document{
			DocumentName:     "document",
			Key:              utcRefNo,
			DocumentNo:       docElectronicData["documentNo"].(string),
			UTCRefNo:         utcRefNo,
			BatchNo:          submitDocumentArgs.BatchNo,
			DocumentType:     submitDocumentArgs.DocumentType,
			DocumentSubType:  submitDocumentArgs.DocumentSubType,
			Customer:         submitDocumentArgs.Customer,
			Override:         submitDocumentArgs.Override,
			ElectronicData:   mappedElectronicData, //these are the dynamic fields
			Status:           status.UnderProcess,
			ProcessingStatus: processingStatus.Pending,
			UploadedOn:       getEpochTime(),
			UploadedBy:       submitDocumentArgs.OrgCode,
			UploadType:       submitDocumentArgs.UploadType,
			BankRefNumbers:   submitDocumentArgs.BankRefNumbers,
			BankCode:         submitDocumentArgs.OrgCode,
		}
		if !batchImagesExists {
			documentData.FileHash = submitDocumentArgs.BatchFileImage.Hash
		}
		documentData.Type = incomingType
		documentData.BankCode = submitDocumentArgs.OrgCode
		fmt.Println("\n\n >>>>>>>> submitDocumentArgs.BankCode >>>>>>> ", submitDocumentArgs.OrgCode)
		fmt.Println("\n >>>>>>>> documentData.Bankcode >>>>>>> ", documentData.BankCode)
		//marshal prepared document data
		documentDataMarshalled, errorMarshal := json.Marshal(documentData)
		if errorMarshal != nil {
			fmt.Println("Marshal failed for documentData !!!!!!", errorMarshal)
			return shim.Error(errorMarshal.Error())
		}
		fmt.Println("Marshalled documentData: ", documentDataMarshalled)
		//insert marshalled document data
		errorInsert = insertData(&stub, documentData.Key, docCollection, documentDataMarshalled)
		//raise shim error message if insertion fails.
		if errorInsert != nil {
			fmt.Println("Insertion failed of documentDataMarshalled !!!!!!", errorInsert)
			return shim.Error(errorInsert.Error())
		}
	}

	additionalData := &AdditionalBatchData{
		BatchIndex: documentBatchData.BatchIndex,
	}
	fmt.Println("additionalData for EventOnPerformOCR: ", additionalData)
	_, _ = RaiseEventData(stub, "EventOnPerformOCR", additionalData)

	fmt.Println("submitDocument function executed successfully")

	return shim.Success(nil)
}
