package main

import (
	"encoding/json"
	"fmt"
	"github.com/hyperledger/fabric/core/chaincode/shim"
	pb "github.com/hyperledger/fabric/protos/peer"
	"strconv"
)

//This method is used for correction of the data for an existing document
func (t *UTCChainCode) resubmitDocument(stub hypConnect, args []string, functionName string) pb.Response {
	fmt.Println("resubmitDocument: ", args)

	if len(args) <= 0 {
		return shim.Error("Invalid Arguments")
	}

	var processingStatus = getProcessingStatus()

	var correctData []CorrectData
	errorUnmarshal := json.Unmarshal([]byte(args[1]), &correctData)
	if errorUnmarshal != nil {
		fmt.Println("Invalid Argument for correctData !!!!!!", errorUnmarshal)
		return shim.Error("Invalid Argument for correctData !!!!!!" + errorUnmarshal.Error())
	}
	fmt.Println("Unmarshaled correctData: ", correctData)

	resubmitDocumentArgs := &ParamsResubmitDocument{
		BatchNo:     sanitize(args[0], "string").(string),
		CorrectData: correctData,
	}

	for _, docCorrectData := range resubmitDocumentArgs.CorrectData {
		fmt.Println("document correct data: ", docCorrectData)

		utcRefNo := docCorrectData.UTCRefNo
		bankCode, errorGetBankCode := getBankCode(stub, utcRefNo)
		if errorGetBankCode != nil {
			return shim.Error(errorGetBankCode.Error())
		}

		//fetch existing document
		docCollection := "documents" + "_" + bankCode
		documentData, errorGetDocumentData := getDocumentData(stub, utcRefNo, docCollection)
		if errorGetDocumentData != nil {
			return shim.Error(errorGetDocumentData.Error())
		}
		fmt.Println("fetched documentData: ", documentData)

		if documentData.ProcessingStatus != processingStatus.Mismatched {
			return shim.Error("Status is not " + processingStatus.Mismatched + " for the document: " + documentData.Key)
		}

		fmt.Println("lengths", len(documentData.MismatchFields), len(docCorrectData.FieldsData))
		/*if len(documentData.MismatchFields) != len(docCorrectData.FieldsData) {
			return shim.Error("Correct Data fields are not valid for the document: " + documentData.Key)
		}*/

		fmt.Println("documentData.MismatchFields: ", documentData.MismatchFields)
		tempMap := make(map[string]MismatchField)
		for _, field := range documentData.MismatchFields {
			if field.Index == -1 {
				tempMap[field.FieldName] = field
			} else {
				tempMap[field.FieldName+"_"+strconv.Itoa(field.Index)] = field
			}
		}

		if len(docCorrectData.FieldsData) < len(documentData.MismatchFields) {
			return shim.Error("Please provide all mismatch fields")
		}
		for i, field := range docCorrectData.FieldsData {
			fmt.Println("tempMap: ", tempMap)
			if _, ok := tempMap[field.FieldName]; ok {
				fmt.Println("incoming normal field: ", field)
				fmt.Println("mismatch field: ", tempMap[field.FieldName])
				documentData.ProcessingData[field.FieldName] = field.Value
				field.Index = -1
				docCorrectData.FieldsData[i] = field
				delete(tempMap, field.FieldName)
			} else if _, ok := tempMap[field.FieldName+"_"+strconv.Itoa(field.Index)]; ok {
				key := field.FieldName + "_" + strconv.Itoa(field.Index)
				fmt.Println("incoming array field: ", field, field.Index)
				fmt.Println("mismatch field: ", tempMap[key], tempMap[key].Index)
				fmt.Println("indexes: ", tempMap[key].Index, field.Index)
				//if tempMap[key].Index == field.Index {
				fmt.Println("index valid: ", tempMap[key].Index, field.Index)
				if slice, ok := documentData.ProcessingData[field.FieldName].([]interface{}); ok {
					slice[field.Index] = field.Value
					documentData.ProcessingData[field.FieldName] = slice
				}
				//} else {
				//	fmt.Println("index invalid: ", tempMap[key].Index, field.Index)
				//	return shim.Error("Correct Data fields are not valid for the document: " + documentData.Key)
				//}
				delete(tempMap, key)
			} else {
				fmt.Println("field not found adding extra to processing data: ", field.FieldName)
				//return shim.Error("Correct Data fields are not valid for the document: " + documentData.Key)

			}
		}

		documentData.CorrectData = docCorrectData
		documentData.ProcessingStatus = processingStatus.Corrected

		fmt.Println("final document data !!! ", documentData.ProcessingData)
		//marshal final document data
		documentDataMarshalled, errorMarshal := json.Marshal(documentData)
		if errorMarshal != nil {
			fmt.Println("Marshal failed for documentData !!!!!!", errorMarshal)
			return shim.Error(errorMarshal.Error())
		}
		fmt.Println("Marshalled documentData: ", documentDataMarshalled)
		//insert marshalled document data
		errorInsert := insertData(&stub, documentData.Key, docCollection, documentDataMarshalled)
		//raise shim error message if insertion fails.
		if errorInsert != nil {
			fmt.Println("Insertion failed of documentDataMarshalled !!!!!!", errorInsert)
			return shim.Error(errorInsert.Error())
		}

	}

	fmt.Println("All documents corrected successfully")

	_, _ = RaiseEventData(stub, "EventOnDataCorrected")
	return shim.Success(nil)
}
